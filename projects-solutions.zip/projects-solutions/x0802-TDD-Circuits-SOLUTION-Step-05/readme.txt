Refactoring:
	calculate eingef�hrt
	wird in toggle aufgerufen
	toggle final