package circuits;

public class NotCircuit extends Circuit {

	public NotCircuit() {
		super(1, 1);
		this.outputStates[0] = true;
	}
	@Override
	public void calculate() {
		this.outputStates[0] = ! this.inputStates[0];
	}
}
