package circuits;

public abstract class Circuit {
	protected final boolean[] inputStates;
	protected final boolean[] outputStates;

	public Circuit(final int inputCount, final int outputCount) {
		this.inputStates = new boolean[inputCount];
		this.outputStates = new boolean[outputCount];
	}

	protected abstract void calculate();

	public final void toggle(final int index) {
		this.inputStates[index] = !this.inputStates[index];
		this.calculate();
	}

	public final int getInputCount() {
		return this.inputStates.length;
	}

	public final int getOutputCount() {
		return this.outputStates.length;
	}

	public boolean inputState(final int index) {
		return this.inputStates[index];
	}

	public boolean outputState(final int index) {
		return this.outputStates[index];
	}
}
