package circuits;

public class AndCircuit extends Circuit {

	public AndCircuit() {
		super(2, 1);
	}
	@Override
	public void calculate() {
		this.outputStates[0] = this.inputStates[0] && this.inputStates[1];
	}
}
