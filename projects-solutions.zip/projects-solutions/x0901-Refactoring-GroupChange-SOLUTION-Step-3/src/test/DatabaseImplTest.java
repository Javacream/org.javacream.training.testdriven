package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import domain.Customer;
import domain.Product;
import services.Database;
import services.DatabaseImpl;
import util.test.XAssert;

public class DatabaseImplTest {

	@Test
	public void test() {
		final StringReader cr = new StringReader("1000,Nowak\n2000,Rueschenpoehler\n");
		final StringReader pr = new StringReader("100,Jever,11\n200,Veltins,12\n");
		final Database db = new DatabaseImpl(cr, pr);
		this.assertEquals(new Customer(1000, "Nowak"), db.getCustomer(1000));
		this.assertEquals(new Customer(2000, "Rueschenpoehler"), db.getCustomer(2000));
		this.assertEquals(new Product(100, "Jever", 11), db.getProduct(100));
		this.assertEquals(new Product(200, "Veltins", 12), db.getProduct(200));
	}

	@Test
	public void testException() {
		final StringReader cr = new StringReader("");
		final StringReader pr = new StringReader("");
		final Database db = new DatabaseImpl(cr, pr);
		XAssert.assertThrows(RuntimeException.class, () -> db.getCustomer(1000)); 
		XAssert.assertThrows(RuntimeException.class, () -> db.getProduct(100)); 
	}

	private void assertEquals(final Customer c0, final Customer c1) {
		Assert.assertEquals(c0.nr, c1.nr);
		Assert.assertEquals(c0.name, c1.name);
	}
	private void assertEquals(final Product p0, final Product p1) {
		Assert.assertEquals(p0.nr, p1.nr);
		Assert.assertEquals(p0.name, p1.name);
		Assert.assertEquals(p0.price, p1.price);
	}
}
