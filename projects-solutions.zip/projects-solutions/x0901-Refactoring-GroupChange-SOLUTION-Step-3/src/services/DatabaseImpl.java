package services;

import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import domain.Customer;
import domain.Product;
import util.CSVReader;

public class DatabaseImpl implements Database {

	private final Map<Integer, Customer> customers = new HashMap<>();
	private final Map<Integer, Product> products = new HashMap<>();

	public DatabaseImpl(final Reader customerReader, final Reader productReader) {
		this.readCustomers(customerReader);
		this.readProducts(productReader);
	}

	private void readCustomers(final Reader r) {
		final CSVReader reader = new CSVReader(r, 2, ",");
		for (String[] tokens = reader.readLine(); tokens != null; tokens = reader.readLine()) {
			final Customer c = new Customer(Integer.parseInt(tokens[0]), tokens[1]);
			this.customers.put(c.nr, c);
		}
	}

	private void readProducts(final Reader r) {
		final CSVReader reader = new CSVReader(r, 3, ",");
		for (String[] tokens = reader.readLine(); tokens != null; tokens = reader.readLine()) {
			final Product p = new Product(Integer.parseInt(tokens[0]), tokens[1], Integer.parseInt(tokens[2]));
			this.products.put(p.nr, p);
		}
	}

	@Override
	public Customer getCustomer(final int nr) {
		final Customer c = this.customers.get(nr);
		if (c == null)
			throw new RuntimeException("Customer " + nr + " not found");
		return c;
	}

	@Override
	public Product getProduct(final int nr) {
		final Product p = this.products.get(nr);
		if (p == null)
			throw new RuntimeException("Product " + nr + " not found");
		return p;
	}
}
