package services;

import domain.Customer;
import domain.Product;

public interface Database {
	public abstract Customer getCustomer(int nr);
	public abstract Product getProduct(int nr);
}
