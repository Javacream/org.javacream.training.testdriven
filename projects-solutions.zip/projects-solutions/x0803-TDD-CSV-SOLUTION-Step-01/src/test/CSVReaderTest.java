package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import util.CSVReader;
import util.test.XAssert;

public class CSVReaderTest {

	@Test
	public void testEmptyInput() {
		final String s = "";
		final CSVReader reader = new CSVReader(new StringReader(s), 2, ";");
		Assert.assertNull(reader.readLine());
	}

	@Test
	public void testOneLine() {
		final String s = "111;222\n";
		final CSVReader reader = new CSVReader(new StringReader(s), 2, ";");
		Assert.assertArrayEquals(new String[] { "111", "222" }, reader.readLine());
		Assert.assertNull(reader.readLine());
	}

	@Test
	public void testThreeLines() {
		final String s = "111;222\n333;444\n555;666\n";
		final CSVReader reader = new CSVReader(new StringReader(s), 2, ";");
		Assert.assertArrayEquals(new String[] { "111", "222" }, reader.readLine());
		Assert.assertArrayEquals(new String[] { "333", "444" }, reader.readLine());
		Assert.assertArrayEquals(new String[] { "555", "666" }, reader.readLine());
		Assert.assertNull(reader.readLine());
	}

	@Test
	public void testException() {
		final String s = "111\n";
		final CSVReader reader = new CSVReader(new StringReader(s), 2, ";");
		XAssert.assertThrows(RuntimeException.class, () -> reader.readLine());
	}

	@Test
	public void testNewLine() {
		final String s = "\n111;222\n\n333;444\n\n";
		final CSVReader reader = new CSVReader(new StringReader(s), 2, ";");
		Assert.assertArrayEquals(new String[] { "111", "222" }, reader.readLine());
		Assert.assertArrayEquals(new String[] { "333", "444" }, reader.readLine());
		Assert.assertNull(reader.readLine());
	}

}
