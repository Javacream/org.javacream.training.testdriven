package appl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;

public class Trimmer {

	public void trim(final String inputFileName, final String outputFileName) throws IOException {
		try (final InputStreamReader reader = new InputStreamReader(new FileInputStream(inputFileName))) {
			try (PrintWriter writer = new PrintWriter(outputFileName)) {
				this.trim(reader, writer);
			}
		}
	}

	public void trim(final Reader r, final Writer w) throws IOException {
		try (final BufferedReader reader = new BufferedReader(r)) {
			try (PrintWriter writer = new PrintWriter(w)) {
				String line;
				while ((line = reader.readLine()) != null) {
					line = line.trim();
					if (line.length() > 0 && !line.startsWith("//"))
						writer.println(line);
				}
			}
		}
	}
}
