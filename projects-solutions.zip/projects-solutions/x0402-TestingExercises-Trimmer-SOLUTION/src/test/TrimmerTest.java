package test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.Assert;
import org.junit.Test;

import appl.Trimmer;

public class TrimmerTest {

	private static final String NL = System.getProperty("line.separator");

	@Test
	public void TestSimple() throws IOException
	{
		final Trimmer trimmer = new Trimmer();

		final Reader r = new StringReader("aaa\n\n\nbbb\n\nccc\n");
		final Writer w = new StringWriter();
		trimmer.trim(r, w);
		Assert.assertEquals("aaa" + NL + "bbb" + NL + "ccc" + NL, w.toString());
	}

	@Test
	public void TestBlanks() throws IOException
	{
		final Trimmer trimmer = new Trimmer();

		final Reader r = new StringReader("  aaa    \n\n\n  bbb\n\nccc\n");
		final Writer w = new StringWriter();
		trimmer.trim(r, w);
		Assert.assertEquals("aaa" + NL + "bbb" + NL + "ccc" + NL, w.toString());
	}

	@Test
	public void TestComments() throws IOException
	{
		final Trimmer trimmer = new Trimmer();

		final Reader r = new StringReader("//aaa\n\n\n//bbb\n\nccc\n");
		final Writer w = new StringWriter();
		trimmer.trim(r, w);
		Assert.assertEquals("ccc" + NL, w.toString());
	}
}
