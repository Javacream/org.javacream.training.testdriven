Preconditions
