package circuits;

import java.util.ArrayList;
import java.util.List;

public class Output {

	private boolean state;
	final List<Input> targets = new ArrayList<>();

	void setState(final boolean state) {
		if (state != this.state) {
			this.state = state;
			this.targets.forEach(target -> target.setState(this.getState()));
		}
	}

	public boolean getState() {
		return this.state;
	}

	public void connectTo(final Input input) {
		if (input.isConnected())
			throw new RuntimeException("cannot connectTo. input is connected");
		input.source = this;
		this.targets.add(input);
		input.setState(this.getState());
		input.getOwner().calculate();
	}
}
