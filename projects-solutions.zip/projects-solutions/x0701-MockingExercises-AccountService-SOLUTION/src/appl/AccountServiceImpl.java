package appl;

import java.util.Date;

public class AccountServiceImpl implements AccountService {

	public static final String MAIL_RECEIVER = "Programmers";
	public static final String MAIL_MESSAGE = "Check balance before calling withdraw";

	private final AccountDAO dao;
	private final MailService mailService;

	public AccountServiceImpl(final AccountDAO dao, final MailService mailService) {
		this.dao = dao;
		this.mailService = mailService;
	}

	@Override
	public Account findAccount(final int nr) {
		return this.dao.findAccount(nr);
	}

	@Override
	public void createAccount(final int nr) {
		final Account account = new Account(nr, 0);
		this.dao.insertAccount(account);
	}

	@Override
	public void deposit(final int nr, final int amount, final Date date) {
		final Account account = this.findAccount(nr);
		if (account == null)
			throw new RuntimeException("Account " + nr + " not found");
		account.balance += amount;
		this.dao.updateAccount(account);
		this.dao.insertMovement(new Movement(nr, date, amount));
	}

	@Override
	public void withdraw(final int nr, final int amount, final Date date) {
		final Account account = this.findAccount(nr);
		if (account == null)
			throw new RuntimeException("Account " + nr + " not found");
		if (account.balance < amount) {
			this.mailService.sendMail(MAIL_RECEIVER, MAIL_MESSAGE);
			throw new RuntimeException("Account " + nr + " : cannot withdraw " + amount);
		}
		account.balance -= amount;
		this.dao.updateAccount(account);
		this.dao.insertMovement(new Movement(nr, date, -amount));
	}

	@Override
	public void transfer(final int fromNr, final int toNr, final int amount, final Date date) {
		// this will run in a transaction....
		this.withdraw(fromNr, amount, date);
		this.deposit(toNr, amount, date);
	}
}
