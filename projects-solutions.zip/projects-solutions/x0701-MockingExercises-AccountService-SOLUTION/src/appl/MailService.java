package appl;

public interface MailService {
	public abstract void sendMail(String recipient, String message);
}
