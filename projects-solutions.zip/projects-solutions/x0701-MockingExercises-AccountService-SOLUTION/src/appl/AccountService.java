package appl;

import java.util.Date;

public interface AccountService {
	public abstract Account findAccount(int nr);
	public abstract void createAccount(int nr);
	public abstract void deposit(int nr, int amount, Date date);
	public abstract void withdraw(int nr, int amount, Date date);
	public abstract void transfer(int fromNr, int toNr, int amount, Date date);
}
