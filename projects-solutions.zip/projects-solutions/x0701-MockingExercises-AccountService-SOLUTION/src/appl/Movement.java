package appl;

import java.util.Date;
import java.util.Objects;

public class Movement {

	public final int accountNr;
	public final Date date;
	public final int amount;

	public Movement(final int accountNr, final Date date, final int amount) {
		Objects.requireNonNull(date);
		this.accountNr = accountNr;
		this.date = date;
		this.amount = amount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.accountNr;
		result = prime * result + this.amount;
		result = prime * result + this.date.hashCode();
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null || this.getClass() != obj.getClass())
			return false;
		final Movement other = (Movement) obj;
		return this.accountNr == other.accountNr && this.date.equals(other.date) && this.amount == other.amount;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() +" [" + this.accountNr + ", " + this.date + ", " + this.amount + "]";
	}
}
