package appl;

public class Account
{
	public final int nr;
	public int balance;

	public Account(final int nr, final int balance)
	{
		this.nr = nr;
		this.balance = balance;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.balance;
		result = prime * result + this.nr;
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null|| this.getClass() != obj.getClass())
			return false;
		final Account other = (Account) obj;
		return this.nr == other.nr && this.balance == other.balance;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.nr + ", " + this.balance + "]";
	}
}
