package appl;

public interface AccountDAO {
	public abstract void insertAccount(Account account);    // may throw RuntimeException (Duplicate key)
	public abstract Account findAccount(int nr);            // may return null;
	public abstract void updateAccount(Account account);    // may throw RuntimeException (Account not found)
	public abstract void insertMovement(Movement movement); 
}
