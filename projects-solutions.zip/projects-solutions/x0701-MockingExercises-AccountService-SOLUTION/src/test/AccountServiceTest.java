package test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import appl.Account;
import appl.AccountDAO;
import appl.AccountService;
import appl.AccountServiceImpl;
import appl.MailService;
import appl.Movement;
import util.test.XAssert;

public class AccountServiceTest {

	private AccountService accountService;
	private AccountDAO accountDAO;
	private MailService mailService;

	@Before
	public void before() {
		this.accountDAO = mock(AccountDAO.class);
		this.mailService = mock(MailService.class);
		this.accountService = new AccountServiceImpl(this.accountDAO, this.mailService);
	}

	@Test
	public void testFindAccount()
	{
		when(this.accountDAO.findAccount(4711)).thenReturn(new Account(4711, 42));
		final Account account = this.accountService.findAccount(4711);
		Assert.assertEquals(new Account(4711, 42), account);
	}

	@Test
	public void testCreateAccount() {
		this.accountService.createAccount(4711);
		verify(this.accountDAO).insertAccount(new Account(4711, 0));
	}

	@Test
	public void testCreateAccountDuplicateKey() {
		this.accountDAO.insertAccount(new Account(4711, 0));
		doThrow(RuntimeException.class);
		XAssert.assertThrows(Exception.class, () -> this.accountService.createAccount(4711));
	}

	@Test
	public void testDeposit() {
		final Date date = new Date();
		when(this.accountDAO.findAccount(4711)).thenReturn(new Account(4711, 1000));
		this.accountService.deposit(4711, 2000, date);
		verify(this.accountDAO).updateAccount(new Account(4711, 3000));
		verify(this.accountDAO).insertMovement(new Movement(4711, date, 2000));
	}

	@Test
	public void testWithdrawWhenAvailable() {
		final Date date = new Date();
		when(this.accountDAO.findAccount(4711)).thenReturn(new Account(4711, 5000));
		this.accountService.withdraw(4711, 2000, date);
		verify(this.accountDAO).updateAccount(new Account(4711, 3000));
		verify(this.accountDAO).insertMovement(new Movement(4711, date, -2000));
	}

	@Test
	public void testWithdrawWhenNotAvailable() {
		when(this.accountDAO.findAccount(4711)).thenReturn(new Account(4711, 3000));
		XAssert.assertThrows(Exception.class, () -> this.accountService.withdraw(4711, 4000, new Date()));
		verify(this.accountDAO, never()).updateAccount(any());
		verify(this.accountDAO, never()).insertMovement(any());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testWithdrawWhenAccountNotFound() {
		when(this.accountDAO.findAccount(4711)).thenThrow(RuntimeException.class);
		XAssert.assertThrows(Exception.class, () -> this.accountService.withdraw(4711, 4000, new Date()));
	}

	@Test
	public void testTransfer() {
		final Date date = new Date();
		when(this.accountDAO.findAccount(4711)).thenReturn(new Account(4711, 10000));
		when(this.accountDAO.findAccount(4712)).thenReturn(new Account(4712, 5000));
		this.accountService.transfer(4711, 4712, 4000, date);
		verify(this.accountDAO).updateAccount(new Account(4711, 6000));
		verify(this.accountDAO).insertMovement(new Movement(4711, date, -4000));
		verify(this.accountDAO).updateAccount(new Account(4712, 9000));
		verify(this.accountDAO).insertMovement(new Movement(4712, date, 4000));
	}
}
