package util;

import java.lang.reflect.Field;
import java.util.Objects;

public class Mapper<T> {

	private final Class<T> cls;
	private final String[] fieldNames;

	public Mapper(final Class<T> cls, final String... fieldNames) {
		Objects.requireNonNull(cls);
		Objects.requireNonNull(fieldNames);
		this.cls = cls;
		this.fieldNames = fieldNames;
	}

	public T map(final String... stringValues) {
		Objects.requireNonNull(stringValues);
		if (stringValues.length != this.fieldNames.length)
			throw new RuntimeException("illegal count of stringValues");
		try {
			final T object = this.cls.newInstance();
			for (int i = 0; i < stringValues.length; i++) {
				final String fieldName = this.fieldNames[i];
				final String stringValue = stringValues[i];
				final Field field = this.cls.getField(fieldName);
				final Object value = ParserSupport.parse(field.getType(), stringValue);
				field.set(object, value);
			}
			return object;
		}
		catch(final Exception e) {
			throw new RuntimeException(e);
		}
	}
}
