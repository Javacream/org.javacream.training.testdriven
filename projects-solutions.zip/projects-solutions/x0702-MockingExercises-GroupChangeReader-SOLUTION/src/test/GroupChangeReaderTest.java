package test;

import static org.mockito.Mockito.mock;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import appl.GroupChangeReader;
import appl.Order;
import appl.Processor;

public class GroupChangeReaderTest {

	private Processor<Order,Integer> processor;

	@SuppressWarnings("unchecked")
	@Before
	public void before() {
		this.processor = mock(Processor.class);
	}

	@Test
	public void testEmptyInput()
	{
		final Order[] orders = new Order[] {  };

		GroupChangeReader.read(Arrays.asList(orders), (final Order order) -> order.customerNr, this.processor);

		Mockito.verify(this.processor).processBegin();
		Mockito.verify(this.processor).processEnd();
	}

	@Test
	public void testGroupWithOnePosition()
	{
		final Order[] orders = new Order[] {  
				new Order(1000, 100, 10)
		};

		GroupChangeReader.read(Arrays.asList(orders), (final Order order) -> order.customerNr, this.processor);

		Mockito.verify(this.processor).processBegin();
		Mockito.verify(this.processor).processGroupBegin(1000);
		Mockito.verify(this.processor).processPosition(orders[0]);
		Mockito.verify(this.processor).processGroupEnd(1000);
		Mockito.verify(this.processor).processEnd();
	}

	@Test
	public void testThreeGroups()
	{
		final Order[] orders = new Order[] {  
				new Order(1000, 100, 1),
				new Order(1000, 200, 1),
				new Order(2000, 100, 2),
				new Order(3000, 300, 3),
				new Order(3000, 200, 2),
				new Order(3000, 100, 1),
		};

		GroupChangeReader.read(Arrays.asList(orders), (final Order order) -> order.customerNr, this.processor);

		Mockito.verify(this.processor).processBegin();
		Mockito.verify(this.processor).processGroupBegin(1000);
		Mockito.verify(this.processor).processPosition(orders[0]);
		Mockito.verify(this.processor).processPosition(orders[1]);
		Mockito.verify(this.processor).processGroupEnd(1000);
		Mockito.verify(this.processor).processGroupBegin(2000);
		Mockito.verify(this.processor).processPosition(orders[2]);
		Mockito.verify(this.processor).processGroupEnd(2000);
		Mockito.verify(this.processor).processGroupBegin(3000);
		Mockito.verify(this.processor).processPosition(orders[3]);
		Mockito.verify(this.processor).processPosition(orders[4]);
		Mockito.verify(this.processor).processPosition(orders[5]);
		Mockito.verify(this.processor).processGroupEnd(3000);
		Mockito.verify(this.processor).processEnd();
	}
}
