package appl;

import java.util.Arrays;

public class GroupChangeReaderDemo {

	private static class PrintProcessor implements Processor<Order, Integer> {
		@Override
		public void processBegin() {
			System.out.println("Begin");
		}

		@Override
		public void processGroupBegin(final Integer customerNr) {
			System.out.println("\tGroupBegin " + customerNr);
		}

		@Override
		public void processPosition(final Order order) {
			System.out.println("\t\tPosition " + order);
		}

		@Override
		public void processGroupEnd(final Integer customerNr) {
			System.out.println("\tGroupEnd " + customerNr);
		}

		@Override
		public void processEnd() {
			System.out.println("End");
		}
	}

	public static void main(final String[] args) {
		final Order[] orders = new Order[] {
				new Order(1000, 100, 1),
				new Order(1000, 200, 1),
				new Order(2000, 100, 2),
				new Order(3000, 300, 3),
				new Order(3000, 200, 2),
				new Order(3000, 100, 1),
		};
		GroupChangeReader.read(Arrays.asList(orders), (final Order order) -> order.customerNr, new PrintProcessor());
	}
}
