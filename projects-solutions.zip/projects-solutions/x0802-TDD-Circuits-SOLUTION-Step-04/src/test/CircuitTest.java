package test;

import org.junit.Assert;
import org.junit.Test;

import circuits.AndCircuit;
import circuits.Circuit;
import circuits.NotCircuit;
import circuits.OrCircuit;

public class CircuitTest {
	@Test
	public void testAnd() {
		final Circuit c = new AndCircuit();
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.inputState(0));
		Assert.assertFalse(c.inputState(1));
		Assert.assertFalse(c.outputState(0));
	}

	@Test
	public void testOr() {
		final Circuit c = new OrCircuit();
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.inputState(0));
		Assert.assertFalse(c.inputState(1));
		Assert.assertFalse(c.outputState(0));
	}

	@Test
	public void testNot() {
		final Circuit c = new NotCircuit();
		Assert.assertEquals(1, c.getInputCount());
		Assert.assertFalse(c.inputState(0));
		Assert.assertTrue(c.outputState(0));
	}

	@Test
	public void testToggleAnd() {
		final Circuit c = new AndCircuit();
		c.toggle(0);
		Assert.assertTrue(c.inputState(0));
		Assert.assertFalse(c.inputState(1));
		Assert.assertFalse(c.outputState(0));
		c.toggle(1);
		Assert.assertTrue(c.inputState(0));
		Assert.assertTrue(c.inputState(1));
		Assert.assertTrue(c.outputState(0));
		c.toggle(0);
		Assert.assertFalse(c.inputState(0));
		Assert.assertTrue(c.inputState(1));
		Assert.assertFalse(c.outputState(0));
	}
	@Test
	public void testToggleOr() {
		final Circuit c = new OrCircuit();
		c.toggle(0);
		Assert.assertTrue(c.inputState(0));
		Assert.assertFalse(c.inputState(1));
		Assert.assertTrue(c.outputState(0));
		c.toggle(1);
		Assert.assertTrue(c.inputState(0));
		Assert.assertTrue(c.inputState(1));
		Assert.assertTrue(c.outputState(0));
		c.toggle(0);
		Assert.assertFalse(c.inputState(0));
		Assert.assertTrue(c.inputState(1));
		Assert.assertTrue(c.outputState(0));
		c.toggle(1);
		Assert.assertFalse(c.inputState(0));
		Assert.assertFalse(c.inputState(1));
		Assert.assertFalse(c.outputState(0));
	}
	@Test
	public void testToggleNot() {
		final Circuit c = new NotCircuit();
		c.toggle(0);
		Assert.assertTrue(c.inputState(0));
		Assert.assertFalse(c.outputState(0));
		c.toggle(0);
		Assert.assertFalse(c.inputState(0));
		Assert.assertTrue(c.outputState(0));
	}
}
