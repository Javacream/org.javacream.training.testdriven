package circuits;

public class NotCircuit extends Circuit {

	public NotCircuit() {
		super(1, 1);
		this.outputStates[0] = true;
	}
	@Override
	public void toggle(final int index) {
		this.inputStates[index] = !this.inputStates[index];
		this.outputStates[0] = ! this.inputStates[0];
	}
}
