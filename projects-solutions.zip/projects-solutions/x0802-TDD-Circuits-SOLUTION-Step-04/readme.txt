toggle in Circuit spezifiziert
toggle in abgeleiteten Klassen implementiert.