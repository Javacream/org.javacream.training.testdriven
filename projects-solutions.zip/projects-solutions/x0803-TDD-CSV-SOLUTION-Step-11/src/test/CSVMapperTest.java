package test;

import java.io.StringReader;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import util.CSVMapper;

public class CSVMapperTest {

	@Test
	public void testWithHeader() {
		final String s = "isbn;title;year;price\n" + "1111;Pascal;1970;10.10\n" + "2222;Modula;1980;20.20\n";
		final CSVMapper<Book> mapper = new CSVMapper<>(Book.class, new StringReader(s), 4, ";");
		Assert.assertEquals(new Book("1111", "Pascal", 1970, 10.10), mapper.read()); 
		Assert.assertEquals(new Book("2222", "Modula", 1980, 20.20), mapper.read()); 
		Assert.assertNull(mapper.read());
	}

	@Test
	public void testWithoutHeader() {
		final String s = "1111;Pascal;1970;10.10\n" + "2222;Modula;1980;20.20\n";
		final String[] header = new String[] { "isbn", "title", "year", "price" };
		final CSVMapper<Book> mapper = new CSVMapper<>(Book.class, new StringReader(s), 4, ";", header);
		Assert.assertEquals(new Book("1111", "Pascal", 1970, 10.10), mapper.read()); 
		Assert.assertEquals(new Book("2222", "Modula", 1980, 20.20), mapper.read()); 
		Assert.assertNull(mapper.read());
	}

	@Test
	public void testMapAll() {
		final String s = "isbn;title;year;price\n" + "1111;Pascal;1970;10.10\n" + "2222;Modula;1980;20.20\n";
		final CSVMapper<Book> mapper = new CSVMapper<>(Book.class, new StringReader(s), 4, ";");
		final List<Book> books = mapper.readAll();
		Assert.assertEquals(new Book("1111", "Pascal", 1970, 10.10), books.get(0)); 
		Assert.assertEquals(new Book("2222", "Modula", 1980, 20.20), books.get(1)); 
	}
}
