package util;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class CSVMapper<T> {
	private final CSVReader csvReader;
	private final Mapper<T> mapper;

	public CSVMapper(final Class<T> cls, final Reader reader, final int columnCount, final String seperator,
			final String[] header) {
		this.csvReader = new CSVReader(reader, columnCount, seperator, header == null);
		this.mapper = new Mapper<T>(cls, header == null ? this.csvReader.getHeader() : header);
	}

	public CSVMapper(final Class<T> cls, final Reader reader, final int columnCount, final String seperator) {
		this(cls, reader, columnCount, seperator, null);
	}

	public T read() {
		final String[] line = this.csvReader.readLine();
		if (line == null)
			return null;
		return this.mapper.map(line);
	}

	public List<T> readAll() {
		final List<T> list = new ArrayList<>();
		for (T obj = this.read(); obj != null; obj = this.read())
			list.add(obj);
		return list;
	}
}
