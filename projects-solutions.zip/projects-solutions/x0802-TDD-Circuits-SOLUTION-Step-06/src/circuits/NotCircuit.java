package circuits;

public class NotCircuit extends Circuit {

	public NotCircuit() {
		super(1, 1);
		this.outputs[0].setState(true);
	}
	@Override
	public void calculate() {
		this.outputs[0].setState(! this.inputs[0].getState());
	}
}
