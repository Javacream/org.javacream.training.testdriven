package circuits;

public class AndCircuit extends Circuit {

	public AndCircuit() {
		super(2, 1);
	}
	@Override
	public void calculate() {
		this.outputs[0].setState(this.inputs[0].getState() && this.inputs[1].getState());
	}
}
