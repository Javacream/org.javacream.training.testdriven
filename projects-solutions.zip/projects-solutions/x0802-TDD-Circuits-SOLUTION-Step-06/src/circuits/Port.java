package circuits;

public class Port {
	private boolean state;
	void setState(final boolean state) {
		this.state = state;
	}
	public boolean getState() {
		return this.state;
	}
}
