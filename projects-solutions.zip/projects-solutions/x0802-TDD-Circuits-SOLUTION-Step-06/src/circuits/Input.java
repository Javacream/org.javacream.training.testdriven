package circuits;

public class Input extends Port {
}
