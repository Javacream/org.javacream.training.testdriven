package circuits;

public class Output extends Port {
}
