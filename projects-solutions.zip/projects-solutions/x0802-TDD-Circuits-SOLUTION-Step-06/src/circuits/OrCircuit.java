package circuits;

public class OrCircuit extends Circuit {

	public OrCircuit() {
		super(2, 1);
	}
	@Override
	public void calculate() {
		this.outputs[0].setState(this.inputs[0].getState() || this.inputs[1].getState());
	}
}
