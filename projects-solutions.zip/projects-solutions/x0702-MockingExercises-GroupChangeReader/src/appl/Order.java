package appl;

public class Order {
	public final int customerNr;
	public final int productNr;
	public final int amount;

	public Order(final int customerNr, final int productNr, final int amount) {
		this.customerNr = customerNr;
		this.productNr = productNr;
		this.amount = amount;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.customerNr + ", " + this.productNr + ", " + this.amount + "]";
	}

}
