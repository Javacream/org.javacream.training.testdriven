package appl;

import java.util.Iterator;
import java.util.function.Function;

public class GroupChanger {
	public static <T, K> void read(final Iterable<T> input, final Function<T, K> keyExtractor,
			final Processor<T, K> processor) {
		final Iterator<T> iterator = input.iterator();
		T current = next(iterator);
		processor.processBegin();
		while (current != null) {
			final K key = keyExtractor.apply(current);
			processor.processGroupBegin(key);
			while (current != null && keyExtractor.apply(current).equals(key)) {
				processor.processPosition(current);
				current = next(iterator);
			}
			processor.processGroupEnd(key);
		}
		processor.processEnd();
	}

	private static <T> T next(final Iterator<T> iterator) {
		return iterator.hasNext() ? iterator.next() : null;
	}
}
