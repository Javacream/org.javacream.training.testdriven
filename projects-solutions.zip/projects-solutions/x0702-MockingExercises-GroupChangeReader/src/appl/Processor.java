package appl;

public interface Processor<T, K> {
	public abstract void processBegin();
	public abstract void processGroupBegin(K key);
	public abstract void processPosition(T obj);
	public abstract void processGroupEnd(K key);
	public abstract void processEnd();
}
