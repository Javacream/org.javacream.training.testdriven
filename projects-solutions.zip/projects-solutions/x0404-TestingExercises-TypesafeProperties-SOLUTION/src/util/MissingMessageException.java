package util;

public class MissingMessageException extends RuntimeException {
	public MissingMessageException(final String key) {
		super(key);
	}
}
