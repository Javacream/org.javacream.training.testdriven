package util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import util.annotations.Default;
import util.annotations.MessagesInterface;

public class SafeMessages {

	static class Handler implements InvocationHandler {

		private final Map<String, String> map;

		public Handler(final Map<String, String> map) {
			this.map = map;
		}

		@Override
		public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
			if (method.isDefault())
				return DynamicProxyHelper.callDefaultMethod(proxy, method, args);
			final String key = method.getName();
			String value = this.map.get(key);
			if (args == null)
				return value;
			for (int i = 0; i < args.length; i++)
				value = value.replace("?" + i, args[i].toString());
			return value;
		}
	}

	public static <T> T load(final Class<T> iface, final Reader reader) throws IOException {
		final Properties properties = new Properties();
		properties.load(reader);
		return load(iface, properties);
	}

	@SuppressWarnings("unchecked")
	public static <T> T load(final Class<T> iface, final Properties properties) {
		Helper.checkInterface(iface, MessagesInterface.class);
		final Map<String, String> map = new HashMap<>();
		final Method[] methods = Helper.getAbstractMethods(iface);
		for (final Method method : methods) {
			final String key = method.getName();
			if (method.getReturnType() != String.class)
				throw new RuntimeException("return type must be Strng: " + key);
			if (method.getParameterCount() > 10)
				throw new RuntimeException("too many parameters: " + key);
			final Default defaultAnnotation = method.getAnnotation(Default.class);
			final String defaultValue = defaultAnnotation == null ? null : defaultAnnotation.value();
			final String propValue = properties.getProperty(key);
			if (propValue == null && defaultValue == null)
				throw new MissingMessageException(key);

			final String stringValue;
			if (propValue != null)
				stringValue = (propValue.isEmpty() && defaultValue != null) ? defaultValue : propValue;
			else
				stringValue = (defaultValue.isEmpty() && propValue != null) ? propValue : defaultValue;

			if (stringValue.isEmpty())
				throw new MissingMessageException(key);
			map.put(key, stringValue);
		}
		return (T) Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class<?>[] { iface },
				new Handler(map));
	}

	public static void createDefaultMessages(final Class<?> iface, final Writer writer) {
		Helper.writeProperties(iface, writer);
	}
}
