package util;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

// see: https://rmannibucau.wordpress.com/2014/03/27/java-8-default-interface-methods-and-jdk-dynamic-proxies/

public class DynamicProxyHelper {
	private static final Constructor<MethodHandles.Lookup> constructor;
	static {
		try {
			constructor = MethodHandles.Lookup.class.getDeclaredConstructor(Class.class, int.class);
			constructor.setAccessible(true);
		}
		catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Object callDefaultMethod(final Object proxy, final Method method, final Object[] args) throws Throwable {
		if (!method.isDefault())
			throw new IllegalArgumentException("default methood required: " + method);
		final Class<?> declaringClass = method.getDeclaringClass();
		return constructor.newInstance(declaringClass, MethodHandles.Lookup.PRIVATE)
				.unreflectSpecial(method, declaringClass).bindTo(proxy).invokeWithArguments(args);
	}

}
