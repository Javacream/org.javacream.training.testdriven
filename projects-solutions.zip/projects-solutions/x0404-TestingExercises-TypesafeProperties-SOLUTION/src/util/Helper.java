package util;

import java.io.PrintWriter;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

import util.annotations.Default;
import util.annotations.MessagesInterface;
import util.annotations.PropertiesInterface;

interface Helper {

	public static void checkInterface(final Class<?> iface) {
		if (!iface.isInterface())
			throw new RuntimeException("Interface required - but found: " + iface.getClass().getName());
		final PropertiesInterface pi = iface.getAnnotation(PropertiesInterface.class);
		final MessagesInterface mi = iface.getAnnotation(MessagesInterface.class);
		if (pi == null && mi == null)
			throw new RuntimeException("Interface must be annotated with " + PropertiesInterface.class.getSimpleName()
					+ " or " + MessagesInterface.class.getSimpleName());
		if (pi != null && mi != null)
			throw new RuntimeException("Interface must be annotated either with " + PropertiesInterface.class.getSimpleName()
					+ " or " + MessagesInterface.class.getSimpleName());
	}

	public static void checkInterface(final Class<?> iface, final Class<? extends Annotation> annotationClass) {
		if (!iface.isInterface())
			throw new RuntimeException("Interface required - but found: " + iface.getClass().getName());
		if (iface.getAnnotation(annotationClass) == null)
			throw new RuntimeException("Interface must be annotated with " + annotationClass.getSimpleName());
	}

	public static Method[] getAbstractMethods(final Class<?> iface) {
		final Method[] methods = iface.getMethods();
		Arrays.sort(methods, Comparator.comparing(m -> m.getName()));
		return Arrays.stream(methods)
				.filter(m -> Modifier.isAbstract(m.getModifiers()))
				.sorted(Comparator.comparing(m -> m.getName()))
				.collect(Collectors.toList())
				.toArray(new Method[] { });
	}

	public static void writeProperties(final Class<?> iface, final Writer writer) {
		Helper.checkInterface(iface);
		try (final PrintWriter w = new PrintWriter(writer)) {
			w.println("# Entries for " + iface.getName() + "\n");
			final Method[] methods = getAbstractMethods(iface);
			for (final Method method : methods) {
				final String key = method.getName();
				w.print(key + " = ");
				final Default defaultAnnotation = method.getAnnotation(Default.class);
				if (defaultAnnotation != null)
					w.print(defaultAnnotation.value());
				w.println();
			}
		}
	}
}
