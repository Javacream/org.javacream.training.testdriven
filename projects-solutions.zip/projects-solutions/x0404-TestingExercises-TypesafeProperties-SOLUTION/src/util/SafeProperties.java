package util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import util.annotations.Default;
import util.annotations.PropertiesInterface;

public class SafeProperties {

	static class Handler implements InvocationHandler {

		private final Map<String, Object> map;

		public Handler(final Map<String, Object> map) {
			this.map = map;
		}

		@Override
		public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
			if (method.isDefault()) 
				return DynamicProxyHelper.callDefaultMethod(proxy, method, args);
			return this.map.get(method.getName());
		}
	}

	public static <T> T load(final Class<T> iface, final Reader reader) throws IOException {
		final Properties properties = new Properties();
		properties.load(reader);
		return load(iface, properties);
	}

	@SuppressWarnings("unchecked")
	public static <T> T load(final Class<T> iface, final Properties properties) {
		Helper.checkInterface(iface, PropertiesInterface.class);
		final Map<String, Object> map = new HashMap<>();
		final Method[] methods = Helper.getAbstractMethods(iface);
		for (final Method method : methods) {
			final String key = method.getName();
			final Default defaultAnnotation = method.getAnnotation(Default.class);
			final String defaultValue = defaultAnnotation == null ? null : defaultAnnotation.value();
			final String propValue = properties.getProperty(key);
			if (propValue == null && defaultValue == null)
				throw new MissingPropertyException(key);

			final String stringValue;
			if (propValue != null)
				stringValue = (propValue.isEmpty() && defaultValue != null) ? defaultValue : propValue;
			else
				stringValue = (defaultValue.isEmpty() && propValue != null) ? propValue : defaultValue;

			if (stringValue.isEmpty()) {
				if (method.getReturnType().isPrimitive())
					throw new MissingPropertyException(key);
				map.put(key, null);
			}
			else {
				final Parser<?> parser = ParserSupport.getParser(method.getReturnType());
				try {
					map.put(key, parser.parse(stringValue.trim()));
				}
				catch(final RuntimeException e) {
					throw new ParserException(key + "=" + stringValue);
				}
			}
		}
		return (T) Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class<?>[] { iface },
				new Handler(map));
	}

	public static void createDefaultProperties(final Class<?> iface, final Writer writer) {
		Helper.writeProperties(iface, writer);
	}

}
