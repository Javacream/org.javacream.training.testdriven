package util;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ParserSupport {

	private ParserSupport() {
	}

	private static final Map<Class<?>, Parser<?>> parsers = new HashMap<>();

	public static <T> void register(final Class<T> cls, final Parser<T> parser) {
		Objects.requireNonNull(cls);
		Objects.requireNonNull(parser);
		if (parsers.containsKey(cls))
			throw new IllegalArgumentException("Parser for '" + cls.getName() + "' already registered");
		parsers.put(cls, parser);
	}

	public static boolean hasParser(final Class<?> cls) {
		Objects.requireNonNull(cls);
		return parsers.containsKey(cls.isPrimitive() ? Primitives.getWrapper(cls) : cls);
	}

	@SuppressWarnings("unchecked")
	public static <T> Parser<T> getParser(final Class<T> cls) {
		Objects.requireNonNull(cls);
		final Parser<T> parser = (Parser<T>)parsers.get(cls.isPrimitive() ? Primitives.getWrapper(cls) : cls);
		if (parser == null)
			throw new IllegalArgumentException("Parser for '" + cls.getName() + "' not found");
		return parser;
	}

	static {
		register(String.class, s -> s);
		register(Byte.class, s -> Byte.parseByte(s));
		register(Short.class, s -> Short.parseShort(s));
		register(Integer.class, s -> Integer.parseInt(s));
		register(Long.class, s -> Long.parseLong(s));
		register(Double.class, s -> Double.parseDouble(s));
		register(Float.class, s -> Float.parseFloat(s));
		register(Character.class, s -> s.charAt(0));
		register(Boolean.class, s -> {
			if (s.equalsIgnoreCase("true")) return true;
			if (s.equalsIgnoreCase("false")) return false;
			throw new RuntimeException("illegal boolean-format");
		});
	}
}
