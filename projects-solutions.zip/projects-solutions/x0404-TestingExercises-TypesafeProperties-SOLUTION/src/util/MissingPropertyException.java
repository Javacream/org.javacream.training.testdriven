package util;

public class MissingPropertyException extends RuntimeException {
	public MissingPropertyException(final String key) {
		super(key);
	}
}
