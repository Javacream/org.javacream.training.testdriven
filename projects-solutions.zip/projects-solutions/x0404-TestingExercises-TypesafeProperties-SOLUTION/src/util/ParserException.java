package util;

public class ParserException extends RuntimeException {
	public ParserException(final String keyValue) {
		super(keyValue);
	}
}
