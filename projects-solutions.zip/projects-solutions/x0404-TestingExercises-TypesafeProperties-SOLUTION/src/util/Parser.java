package util;

public interface Parser<T> {
	T parse(String s);
}
