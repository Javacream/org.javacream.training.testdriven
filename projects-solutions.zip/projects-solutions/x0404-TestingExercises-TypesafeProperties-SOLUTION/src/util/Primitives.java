package util;

import java.util.HashMap;
import java.util.Map;

public class Primitives {
	private Primitives() {
	}

	private static final Map<Class<?>, Class<?>> wrapperTypes = new HashMap<>();
	private static final Map<Class<?>, Class<?>> primitiveTypes = new HashMap<>();

	private static <T> void register(final Class<T> primitive, final Class<T> wrapper) {
		wrapperTypes.put(primitive, wrapper);
		primitiveTypes.put(wrapper, primitive);
	}

	static {
		register(byte.class, Byte.class);
		register(short.class, Short.class);
		register(int.class, Integer.class);
		register(long.class, Long.class);
		register(float.class, Float.class);
		register(double.class, Double.class);
		register(char.class, Character.class);
		register(boolean.class, Boolean.class);
	}

	@SuppressWarnings("unchecked")
	public static <T> Class<T> getPrimitive(final Class<T> wrapper) {
		return (Class<T>) primitiveTypes.get(wrapper);
	}

	@SuppressWarnings("unchecked")
	public static <T> Class<T> getWrapper(final Class<T> primitive) {
		return (Class<T>) wrapperTypes.get(primitive);
	}
}
