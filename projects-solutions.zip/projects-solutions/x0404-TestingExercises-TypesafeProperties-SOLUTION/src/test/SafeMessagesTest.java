package test;

import java.util.Properties;

import org.junit.Assert;
import org.junit.Test;

import util.MissingMessageException;
import util.SafeMessages;
import util.annotations.Default;
import util.annotations.MessagesInterface;
import util.test.XAssert;

public class SafeMessagesTest {

	@MessagesInterface
	public static interface Alpha {
		String greeting();

		String sum(int x, int y, int sum);
	}

	@MessagesInterface
	public static interface Beta {
		@Default("Hallo Welt")
		String greeting();

		@Default("Die Summe von ?0 und ?1 ist ?2")
		String sum(int x, int y, int sum);
	}

	@Test
	public void testAlpha() {
		final Properties props = new Properties();
		props.setProperty("greeting", "Hello World");
		props.setProperty("sum", "?2 is the sum of ?0 and ?1");
		final Alpha alpha = SafeMessages.load(Alpha.class, props);
		Assert.assertEquals("Hello World", alpha.greeting());
		Assert.assertEquals("42 is the sum of 40 and 2", alpha.sum(40, 2, 42));
	}

	@Test
	public void testAlphaMissingPropertyException() {
		final Properties props = new Properties();
		props.setProperty("greeting", "Hello World");
		XAssert.assertThrows(MissingMessageException.class, () -> SafeMessages.load(Alpha.class, props));
	}

	@Test
	public void testBeta() {
		final Properties props = new Properties();
		final Beta beta = SafeMessages.load(Beta.class, props);
		Assert.assertEquals("Hallo Welt", beta.greeting());
		Assert.assertEquals("Die Summe von 40 und 2 ist 42", beta.sum(40, 2, 42));
	}
}
