package test;

import java.util.Properties;

import org.junit.Assert;
import org.junit.Test;

import util.MissingPropertyException;
import util.ParserException;
import util.SafeProperties;
import util.annotations.Default;
import util.annotations.PropertiesInterface;
import util.test.XAssert;

public class SafePropertiesTest {

	@PropertiesInterface
	public static interface Alpha {
		String red();
		String green();
		String blue();
	}

	@Test
	public void testAlpha() {
		final Properties props = new Properties();
		props.setProperty("red", "ROT");
		props.setProperty("green", "GRUEN");
		props.setProperty("blue", "BLAU");
		final Alpha alpha = SafeProperties.load(Alpha.class, props);
		Assert.assertEquals("ROT", alpha.red());
		Assert.assertEquals("GRUEN", alpha.green());
		Assert.assertEquals("BLAU", alpha.blue());
	}

	@Test
	public void testAlphaMissingPropertyException() {
		final Properties props = new Properties();
		props.setProperty("red", "ROT");
		props.setProperty("blue", "BLAU");
		XAssert.assertThrows(MissingPropertyException.class, () -> SafeProperties.load(Alpha.class, props));
	}

	@PropertiesInterface
	public static interface Beta {
		int i();
		double d();
		char c();
		boolean b();
	}

	@Test
	public void testBeta() {
		final Properties props = new Properties();
		props.setProperty("i", "42");
		props.setProperty("d", "3.14");
		props.setProperty("c", "x");
		props.setProperty("b", "true");
		final Beta beta = SafeProperties.load(Beta.class, props);
		Assert.assertEquals(42, beta.i());
		Assert.assertEquals(3.14, beta.d(), 0);
		Assert.assertEquals('x', beta.c());
		Assert.assertTrue(beta.b());
	}

	@Test
	public void testBetaMissingPropertyException() {
		final Properties props = new Properties();
		props.setProperty("i", "42");
		props.setProperty("c", "x");
		XAssert.assertThrows(MissingPropertyException.class, () -> SafeProperties.load(Beta.class, props));
	}

	@Test
	public void testBetaParserException() {
		final Properties props = new Properties();
		props.setProperty("i", "42AAA");
		props.setProperty("d", "3.14");
		props.setProperty("c", "x");
		props.setProperty("b", "true");
		XAssert.assertThrows(ParserException.class, () -> SafeProperties.load(Beta.class, props));
	}

	@PropertiesInterface
	public static interface Gamma {
		@Default("42")int i();
		double d();
		@Default("z") char c();
		@Default("false") boolean b(); 
	}

	@Test
	public void testGamma() {
		final Properties props = new Properties();
		props.setProperty("i", "77");
		props.setProperty("d", "3.14");
		props.setProperty("b", "true");
		final Gamma gamma = SafeProperties.load(Gamma.class, props);
		Assert.assertEquals(77, gamma.i());
		Assert.assertEquals(3.14, gamma.d(), 0);
		Assert.assertEquals('z', gamma.c());
		Assert.assertTrue(gamma.b());
	}

	@Test
	public void testGammaMissingPropertyException() {
		final Properties props = new Properties();
		XAssert.assertThrows(MissingPropertyException.class, () -> SafeProperties.load(Gamma.class, props));
	}
}
