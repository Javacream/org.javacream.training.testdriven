package test;

import java.util.Properties;

import util.SafeProperties;
import util.annotations.PropertiesInterface;

public class SafeDemo {

	@PropertiesInterface
	public static interface Alpha {
		String red();
		String green();
		String blue();
	}

	@PropertiesInterface
	public static interface Beta {
		int i();
		double d();
		char c();
		boolean b();
	}

	public static void main(final String[] args) {
		demoAlpha();
		demoBeta();
	}

	public static void demoAlpha() {
		final Properties props = new Properties();
		props.setProperty("red", "ROT");
		props.setProperty("green", "GRUEN");
		props.setProperty("blue", "BLAU");
		final Alpha alpha = SafeProperties.load(Alpha.class, props);
		System.out.println(alpha.red());
		System.out.println(alpha.green());
		System.out.println(alpha.blue());
	}

	public static void demoBeta() {
		final Properties props = new Properties();
		props.setProperty("i", "42");
		props.setProperty("d", "3.14");
		props.setProperty("c", "x");
		props.setProperty("b", "true");
		final Beta beta = SafeProperties.load(Beta.class, props);
		System.out.println(beta.i());
		System.out.println(beta.d());
		System.out.println(beta.c());
		System.out.println(beta.b());

	}
}
