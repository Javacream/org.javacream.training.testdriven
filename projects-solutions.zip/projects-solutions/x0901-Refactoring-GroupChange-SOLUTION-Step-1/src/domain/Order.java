package domain;

public class Order {
	public int customerNr;
	public int productNr;
	public int amount;

	public Order(final int customerNr, final int productNr, final int amount) {
		this.customerNr = customerNr;
		this.productNr = productNr;
		this.amount = amount;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.customerNr + ", " + this.productNr + ", " + this.amount + "]";
	}

}
