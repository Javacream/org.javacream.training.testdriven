package domain;

public class Product {
	public int nr;
	public String name;
	public int price;
	public Product(final int nr, final String name, final int price) {
		this.nr = nr;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.nr + ", " + this.name + ", " + this.price + "]";
	}

}
