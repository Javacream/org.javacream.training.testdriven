package domain;

public class Customer {
	public int nr;
	public String name;
	public Customer(final int nr, final String name) {
		this.nr = nr;
		this.name = name;
	}
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.nr + ", " + this.name + "]";
	}

}
