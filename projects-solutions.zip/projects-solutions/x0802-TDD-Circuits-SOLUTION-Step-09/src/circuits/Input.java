package circuits;

public class Input {

	private final Circuit owner;
	Output source;
	private boolean state;

	public Input(final Circuit owner) {
		this.owner = owner;
	}

	public Circuit getOwner() {
		return this.owner;
	}

	void setState(final boolean state) {
		if (this.state != state) {
			this.state = state;
			this.owner.calculate();
		}
	}

	public boolean getState() {
		return this.state;
	}

	public void toggle() {
		this.setState(!this.getState());
		this.getOwner().calculate();
	}
}
