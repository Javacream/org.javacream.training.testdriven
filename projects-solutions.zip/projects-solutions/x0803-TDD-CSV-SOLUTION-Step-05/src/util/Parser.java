package util;

@FunctionalInterface
public interface Parser<T> {
	public abstract T parse(final String s);
}
