package util;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ParserSupport {

	private static final Map<Class<?>, Parser<?>> map= new HashMap<>();

	public static <T> void register(final Class<T> type, final Parser<T> parser) {
		Objects.requireNonNull(type);
		Objects.requireNonNull(parser);
		map.put(type, parser);
	}

	public static <T> T parse(final Class<T> type, final String s) {
		Objects.requireNonNull(type);
		Objects.requireNonNull(s);
		@SuppressWarnings("unchecked")
		final Parser<T> parser = (Parser<T>)map.get(type);
		return parser.parse(s);
	}

	static {
		register(String.class, s -> s);
		register(Integer.class, s -> Integer.parseInt(s));
		register(Long.class, s -> Long.parseLong(s));
		register(Float.class, s -> Float.parseFloat(s));
		register(Double.class, s -> Double.parseDouble(s));
		register(Boolean.class, s -> {
			if (s.equalsIgnoreCase("true"))
				return true;
			if (s.equalsIgnoreCase("false"))
				return false;
			throw new RuntimeException("cannot convert '" + s + "' to boolean");
		});
		register(Character.class, s -> {
			if (s.length() != 1)
				throw new RuntimeException("cannot convert '" + s + "' to char");
			return s.charAt(0);
		});
	};
}
