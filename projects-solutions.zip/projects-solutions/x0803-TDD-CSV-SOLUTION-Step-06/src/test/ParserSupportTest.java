package test;

import org.junit.Assert;
import org.junit.Test;

import util.ParserSupport;
import util.test.XAssert;

public class ParserSupportTest {
	@Test
	public void testStart() {
		Assert.assertEquals("Hello", ParserSupport.parse(String.class, "Hello"));
		Assert.assertEquals(42, ParserSupport.parse(Integer.class, "42"));
		Assert.assertEquals(3.14, ParserSupport.parse(Double.class, "3.14"), 0);
		Assert.assertTrue(ParserSupport.parse(Boolean.class, "true"));
		Assert.assertFalse(ParserSupport.parse(Boolean.class, "FAlse"));
		Assert.assertEquals('A', ParserSupport.parse(Character.class, "A"));
	}

	@Test
	public void testExceptions() {
		XAssert.assertThrows(RuntimeException.class, () -> ParserSupport.parse(Integer.class, "42abc"));
		XAssert.assertThrows(RuntimeException.class, () -> ParserSupport.parse(Character.class, "abc"));
		XAssert.assertThrows(RuntimeException.class, () -> ParserSupport.parse(Boolean.class, "wahr"));
	}

	@Test
	public void testSimpleTypes() {
		Assert.assertEquals(42, ParserSupport.parse(int.class, "42"));
		Assert.assertEquals(3.14, ParserSupport.parse(double.class, "3.14"), 0);
		Assert.assertTrue(ParserSupport.parse(boolean.class, "true"));
		Assert.assertFalse(ParserSupport.parse(boolean.class, "FAlse"));
		Assert.assertEquals('A', ParserSupport.parse(char.class, "A"));
	}
}

