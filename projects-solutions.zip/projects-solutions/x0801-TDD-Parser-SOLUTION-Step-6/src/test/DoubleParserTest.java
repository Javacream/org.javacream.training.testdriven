package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import parser.DoubleParser;
import parser.DoubleParserImpl;
import scanner.ScannerImpl;
import util.test.XAssert;

public class DoubleParserTest {

	@Test
	public void test() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2.71  ")));
		Assert.assertEquals(2.71, parser.parse(), 0);
	}

	@Test
	public void testEmpty() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" ")));
		XAssert.assertThrows(RuntimeException.class, () -> parser.parse());
	}

	@Test
	public void testTooManyNumbers() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2.71 3.14")));
		XAssert.assertThrows(RuntimeException.class, () -> parser.parse());
	}

	@Test
	public void testMultiplicative() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2 * 3 / 4 ")));
		Assert.assertEquals(1.5, parser.parse(), 0);
	}

	@Test
	public void testAdditive() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2 + 12 / 4 - 2 * 5")));
		Assert.assertEquals(-5.0, parser.parse(), 0);
	}

	@Test
	public void testNested() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" (2 + 58) / (4 - (2-1)) * 5")));
		Assert.assertEquals(100.0, parser.parse(), 0);
	}
}
