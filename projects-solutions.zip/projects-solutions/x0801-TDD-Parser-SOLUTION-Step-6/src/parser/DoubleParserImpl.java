package parser;

import scanner.Scanner;
import scanner.Symbol;

public class DoubleParserImpl implements DoubleParser {
	private final Scanner scanner;

	public DoubleParserImpl(final Scanner scanner) {
		this.scanner = scanner;
		this.scanner.next();
	}

	@Override
	public double parse() {
		final double value = this.parseAdditive();
		if (this.scanner.currentSymbol() != null)
			throw new RuntimeException("EOF expected");
		return value;
	}

	public double parseAdditive() {
		double value = this.parseMultiplicative();
		while (this.scanner.currentSymbol() == Symbol.PLUS || this.scanner.currentSymbol() == Symbol.MINUS) {
			final boolean plus = this.scanner.currentSymbol() == Symbol.PLUS;
			this.scanner.next();
			final double v = this.parseMultiplicative();
			if (plus)
				value = value + v;
			else
				value = value - v;
		}
		return value;
	}

	public double parseMultiplicative() {
		double value = this.parseSimple();
		while (this.scanner.currentSymbol() == Symbol.TIMES || this.scanner.currentSymbol() == Symbol.DIV) {
			final boolean times = this.scanner.currentSymbol() == Symbol.TIMES;
			this.scanner.next();
			final double v = this.parseSimple();
			if (times)
				value = value * v;
			else
				value = value / v;
		}
		return value;
	}

	public double parseSimple() {
		if(this.scanner.currentSymbol() == Symbol.NUMBER) {
			return this.parseNumber();
		}
		if (this.scanner.currentSymbol() == Symbol.OPEN) {
			this.scanner.next();
			final double value = this.parseAdditive();
			if (this.scanner.currentSymbol() != Symbol.CLOSE) 
				throw new RuntimeException(") expected");
			this.scanner.next();
			return value;
		}
		throw new RuntimeException("Number or ( expected");
	}

	public double parseNumber() {
		if (this.scanner.currentSymbol() != Symbol.NUMBER)
			throw new RuntimeException("Number expected");
		final double value = this.scanner.getNumber();
		this.scanner.next();
		return value;
	}
}
