package appl;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import domain.Customer;
import domain.Order;
import domain.Product;
import util.CSVReader;

public class Application {

	public static void main(final String[] args) {

		final ArrayList<Customer> customers = new ArrayList<>();
		try (FileReader r = new FileReader("customers.txt")) {
			final CSVReader reader = new CSVReader(r, 2, ",");
			for (String[] tokens = reader.readLine(); tokens != null; tokens = reader.readLine())
				customers.add(new Customer(Integer.parseInt(tokens[0]), tokens[1]));
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}

		final ArrayList<Product> products = new ArrayList<>();
		try (FileReader r = new FileReader("products.txt")) {
			final CSVReader productsReader = new CSVReader(r, 3, ",");
			for (String[] tokens = productsReader.readLine(); tokens != null; tokens = productsReader.readLine())
				products.add(new Product(Integer.parseInt(tokens[0]), tokens[1], Integer.parseInt(tokens[2])));
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}

		try (PrintWriter writer = new PrintWriter("result.txt")) {
			try (FileReader r = new FileReader("orders.txt")) {
				final CSVReader reader = new CSVReader(r, 3, ";");
				writer.println("Orders");
				writer.println();
				Order order = readOrder(reader);
				int sum = 0;
				while (order != null) {
					final int customerNr = order.customerNr;
					final Customer customer = getCustomer(customerNr, customers);
					writer.println(customerNr + " " + customer.name);
					int groupSum = 0;
					while (order != null && order.customerNr == customerNr) {
						final int productNr = order.productNr;
						final Product product = getProduct(productNr, products);
						final int positionPrice = product.price * order.amount;
						writer.println("\t" + product.nr + " " + product.name + " " + order.amount + " " + product.price
								+ " " + positionPrice);
						groupSum += positionPrice;
						order = readOrder(reader);
					}
					sum += groupSum;
					writer.println("\t---------");
					writer.println("\t" + groupSum);
					writer.println();
				}
				writer.println("Total:\t" + sum);
				System.out.println("Done. See results.txt");
			}
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static Order readOrder(final CSVReader reader) throws IOException {
		final String[] tokens = reader.readLine();
		if (tokens == null)
			return null;
		final int customerNr = Integer.parseInt(tokens[0]);
		final int produceNr = Integer.parseInt(tokens[1]);
		final int amount = Integer.parseInt(tokens[2]);
		return new Order(customerNr, produceNr, amount);
	}

	private static Customer getCustomer(final int nr, final ArrayList<Customer> customers) {
		for (final Customer c : customers) {
			if (c.nr == nr)
				return c;
		}
		throw new RuntimeException("customer " + nr + " not found");
	}

	private static Product getProduct(final int nr, final ArrayList<Product> products) {
		for (final Product p : products) {
			if (p.nr == nr)
				return p;
		}
		throw new RuntimeException("product " + nr + " not found");
	}
}
