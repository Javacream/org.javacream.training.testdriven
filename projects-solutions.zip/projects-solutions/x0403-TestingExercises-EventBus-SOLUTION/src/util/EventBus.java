package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class EventBus {

	private final Map<Class<?>, List<Consumer<?>>> map = new HashMap<>();

	public <T> void register(final Class<T> eventType, final Consumer<T> subscriber) {
		this.map.computeIfAbsent(eventType, key -> new ArrayList<Consumer<?>>()).add(subscriber);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void fire(final Object event) {
		for(Class<?> type = event.getClass(); type != null; type = type.getSuperclass()) {
			final List<Consumer<?>> subscribers = this.map.get(type);
			if (subscribers != null)
				for (final Consumer subscriber : subscribers) 
					subscriber.accept(event);

		}
	}
}
