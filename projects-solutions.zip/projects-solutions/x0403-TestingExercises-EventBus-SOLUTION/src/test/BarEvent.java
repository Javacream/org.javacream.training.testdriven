package test;

public class BarEvent {
	public final int value;

	public BarEvent(final int value) {
		this.value = value;
	}

	@Override
	public int hashCode() {
		return this.value;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null || this.getClass() != obj.getClass())
			return false;
		final BarEvent other = (BarEvent) obj;
		return this.value == other.value;
	}
}
