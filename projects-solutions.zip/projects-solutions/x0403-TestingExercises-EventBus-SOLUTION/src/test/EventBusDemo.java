package test;

import org.junit.Test;

import util.EventBus;

public class EventBusDemo {

	@Test
	public void TestSimple()
	{
		final EventBus bus = new EventBus();

		bus.register(FooEvent.class, e -> {
			final String v = e.value;
			System.out.println("handler1: " + v);
		});

		bus.register(BarEvent.class, e -> {
			final int v = e.value;
			System.out.println("handler2: " + v);
		});

		bus.register(BarEvent.class, e -> {
			final int v = e.value;
			System.out.println("handler3: " + v);
		});

		bus.register(Object.class, e -> {
			System.out.println("handler4: " + e);
		});

		bus.fire(new FooEvent("Hello"));
		bus.fire(new BarEvent(42));
		bus.fire("Schall und Rauch");
	}

}
