package test;

import java.util.Objects;

public class FooEvent {
	public final String value;

	public FooEvent(final String value) {
		Objects.requireNonNull(value);
		this.value = value;
	}

	@Override
	public int hashCode() {
		return this.value.hashCode();
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null || this.getClass() != obj.getClass())
			return false;
		final FooEvent other = (FooEvent) obj;
		return this.value.equals(other.value);
	}

}
