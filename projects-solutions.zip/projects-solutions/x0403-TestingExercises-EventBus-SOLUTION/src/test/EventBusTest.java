package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import util.EventBus;

public class EventBusTest {

	@Test
	public void TestStringEventWithOneSubscriber() {
		final List<String> events = new ArrayList<>();

		final EventBus bus = new EventBus();

		bus.register(String.class, s -> events.add(s));

		Assert.assertEquals(0, events.size());
		bus.fire("Hello");
		Assert.assertEquals(1, events.size());
		Assert.assertEquals("Hello", events.get(0));
	}

	@Test
	public void TestStringEventsWithOneSubscriber() {
		final EventBus bus = new EventBus();

		final List<String> exptectedEvents = Arrays.asList("one", "two", "three");
		final List<String> actualEvents = new ArrayList<>();

		bus.register(String.class, s -> actualEvents.add(s));

		for (final String event : exptectedEvents)
			bus.fire(event);

		Assert.assertEquals(exptectedEvents, actualEvents);
	}

	@Test
	public void TestThreeSubscribers() {
		final List<String> actualEvents = new ArrayList<>();
		final List<String> exptectedEvents = Arrays.asList("Hello", "Hello", "Hello");

		final EventBus bus = new EventBus();

		bus.register(String.class, s -> actualEvents.add(s));
		bus.register(String.class, s -> actualEvents.add(s));
		bus.register(String.class, s -> actualEvents.add(s));
		bus.fire("Hello");

		Assert.assertEquals(exptectedEvents, actualEvents);
	}

	@Test
	public void TestPolymorphy() {
		final List<Object> actualObjectEvents = new ArrayList<>();
		final List<FooEvent> actualFooEvents = new ArrayList<>();
		final List<BarEvent> actualBarEvents = new ArrayList<>();

		final List<Object> exptectedObjectEvents = Arrays.asList("Hello", new FooEvent("World"), new BarEvent(42));
		final List<FooEvent> exptectedFooEvents = Arrays.asList(new FooEvent("World"));
		final List<BarEvent> exptectedBarEvents = Arrays.asList(new BarEvent(42));

		final EventBus bus = new EventBus();

		bus.register(Object.class, s -> actualObjectEvents.add(s));
		bus.register(FooEvent.class, s -> actualFooEvents.add(s));
		bus.register(BarEvent.class, s -> actualBarEvents.add(s));

		bus.fire("Hello");
		bus.fire(new FooEvent("World"));
		bus.fire(new BarEvent(42));

		Assert.assertEquals(exptectedObjectEvents, actualObjectEvents);
		Assert.assertEquals(exptectedFooEvents, actualFooEvents);
		Assert.assertEquals(exptectedBarEvents, actualBarEvents);
	}
}
