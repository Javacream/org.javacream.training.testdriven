package parser;

import scanner.Scanner;
import scanner.Symbol;

public class DoubleParserImpl implements DoubleParser {
	private final Scanner scanner;

	public DoubleParserImpl(final Scanner scanner) {
		this.scanner = scanner;
		this.scanner.next();
	}

	@Override
	public double parse() {
		final double value = this.parseMultiplicative();
		if (this.scanner.currentSymbol() != null)
			throw new RuntimeException("EOF expected");
		return value;
	}

	public double parseMultiplicative() {
		double value = this.parseNumber();
		while (this.scanner.currentSymbol() == Symbol.TIMES || this.scanner.currentSymbol() == Symbol.DIV) {
			final boolean times = this.scanner.currentSymbol() == Symbol.TIMES;
			this.scanner.next();
			final double v = this.parseNumber();
			if (times)
				value = value * v;
			else
				value = value / v;
		}
		return value;
	}

	public double parseNumber() {
		if (this.scanner.currentSymbol() != Symbol.NUMBER)
			throw new RuntimeException("Number expected");
		final double value = this.scanner.getNumber();
		this.scanner.next();
		return value;
	}
}
