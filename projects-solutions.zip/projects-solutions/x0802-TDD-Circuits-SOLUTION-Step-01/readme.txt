class Circuit:
	Instanzvariablen inputCount und outputCount 
	getInputCount und getOutputCount bereits in Circuit implementiert
Konstruktoren der anderen Circuit-Klassen:
	rufen super auf	
	