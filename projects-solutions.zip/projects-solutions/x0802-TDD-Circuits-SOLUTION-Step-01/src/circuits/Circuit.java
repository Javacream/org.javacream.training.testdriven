package circuits;

public abstract class Circuit {
	private final int inputCount;
	private final int outputCount;

	public Circuit(final int inputCount, final int outputCount) {
		this.inputCount = inputCount;
		this.outputCount = outputCount;
	}

	public final int getInputCount() {
		return this.inputCount;
	}

	public final int getOutputCount() {
		return this.outputCount;
	}
}
