package circuits;

public class AndCircuit extends Circuit {

	public AndCircuit() {
		super(2, 1);
	}
}
