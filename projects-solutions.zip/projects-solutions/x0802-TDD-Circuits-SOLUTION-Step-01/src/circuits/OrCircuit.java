package circuits;

public class OrCircuit extends Circuit {

	public OrCircuit() {
		super(2, 1);
	}
}
