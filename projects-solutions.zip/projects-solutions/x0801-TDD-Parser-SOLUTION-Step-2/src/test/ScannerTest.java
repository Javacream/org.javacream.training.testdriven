package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import scanner.Scanner;
import scanner.ScannerImpl;
import scanner.Symbol;
import util.test.XAssert;

public class ScannerTest {
	@Test
	public void testEOF() {
		final Scanner scanner = new ScannerImpl(new StringReader(""));
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}

	@Test
	public void testOperators() {
		final Scanner scanner = new ScannerImpl(new StringReader("+-*/"));
		scanner.next();
		Assert.assertSame(Symbol.PLUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.MINUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.TIMES, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.DIV, scanner.currentSymbol());
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}

	@Test
	public void testIllegalChar() {
		final Scanner scanner = new ScannerImpl(new StringReader("?"));
		XAssert.assertThrows(RuntimeException.class, () -> scanner.next());
	}

	@Test
	public void testWhitespace() {
		final Scanner scanner = new ScannerImpl(new StringReader(" + -  */  "));
		scanner.next();
		Assert.assertSame(Symbol.PLUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.MINUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.TIMES, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.DIV, scanner.currentSymbol());
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}

	@Test
	public void testNumbers() {
		final Scanner scanner = new ScannerImpl(new StringReader(" +  1 3.14 - *  300/ "));
		scanner.next();
		Assert.assertEquals(Symbol.PLUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertEquals(Symbol.NUMBER, scanner.currentSymbol());
		Assert.assertEquals(1.0, scanner.getNumber(), 0);
		scanner.next();
		Assert.assertEquals(Symbol.NUMBER, scanner.currentSymbol());
		Assert.assertEquals(3.14, scanner.getNumber(), 0);
		scanner.next();
		Assert.assertEquals(Symbol.MINUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertEquals(Symbol.TIMES, scanner.currentSymbol());
		scanner.next();
		Assert.assertEquals(Symbol.NUMBER, scanner.currentSymbol());
		Assert.assertEquals(300, scanner.getNumber(), 0);
		scanner.next();
		Assert.assertEquals(Symbol.DIV, scanner.currentSymbol());
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}
}
