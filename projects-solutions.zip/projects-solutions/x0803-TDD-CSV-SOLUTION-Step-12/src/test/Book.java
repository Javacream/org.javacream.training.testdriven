package test;

import util.Default;

public class Book {
	public String isbn;
	@Default("N.N.")
	public String title;
	public int year;
	@Default("0")
	public double price;

	public Book() {
	}

	public Book(final String isbn, final String title, final int year, final double price) {
		this.isbn = isbn;
		this.title = title;
		this.year = year;
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.isbn == null) ? 0 : this.isbn.hashCode());
		long temp;
		temp = Double.doubleToLongBits(this.price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());
		result = prime * result + this.year;
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (this.getClass() != obj.getClass())
			return false;
		final Book other = (Book) obj;
		if (this.isbn == null) {
			if (other.isbn != null)
				return false;
		}
		else if (!this.isbn.equals(other.isbn))
			return false;
		if (Double.doubleToLongBits(this.price) != Double.doubleToLongBits(other.price))
			return false;
		if (this.title == null) {
			if (other.title != null)
				return false;
		}
		else if (!this.title.equals(other.title))
			return false;
		if (this.year != other.year)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.isbn + ", " + this.title + ", " + this.year + ", " + this.price + "]";
	}
}
