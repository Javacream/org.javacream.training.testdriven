package test;

import org.junit.Assert;
import org.junit.Test;

import util.Mapper;
import util.test.XAssert;


public class MapperTest {

	@Test
	public void testStart() {
		final Mapper<Book> mapper = new Mapper<>(Book.class, "isbn", "title", "year", "price");
		final Book book = mapper.map("1111", "Pascal", "1970", "10.10");
		Assert.assertEquals(new Book("1111", "Pascal", 1970, 10.10), book);
	}
	@Test
	public void testIllegalArgumentCount() {
		final Mapper<Book> mapper = new Mapper<>(Book.class, "isbn", "title", "year", "price");
		XAssert.assertThrows(RuntimeException.class, () -> mapper.map("1111", "Pascal", "1970"));
	}

	@Test
	public void testIllegalArgumentType() {
		final Mapper<Book> mapper = new Mapper<>(Book.class, "isbn", "title", "year", "price");
		XAssert.assertThrows(RuntimeException.class, () -> mapper.map("1111", "Pascal", "abc", "10.10"));
	}

	@Test
	public void testDefault() {
		final Mapper<Book> mapper = new Mapper<>(Book.class, "isbn", "title", "year", "price");
		final Book book = mapper.map("1111", "", "1970", "");
		Assert.assertEquals(new Book("1111", "N.N.", 1970, 0.0), book);
	}

}
