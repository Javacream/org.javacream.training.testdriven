package appl;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;

import services.Database;
import services.DatabaseImpl;
import services.Printer;
import services.PrinterImpl;
import util.CSVReader;
import util.GroupChanger;

public class Application {

	public static void main(final String[] args) {

		final Database database = createDatabase("customers.txt", "products.txt");

		try (final PrintWriter w = new PrintWriter("result.txt")) {
			try (final FileReader r = new FileReader("orders.txt")) {
				final Printer printer = new PrinterImpl(w);
				final CSVReader reader = new CSVReader(r, 3, ";");
				final Orders orders = new Orders(reader);

				final OrderProcessor processor = new OrderProcessor(database, printer);

				GroupChanger.run(orders, order -> order.customerNr, processor);

				System.out.println("Done. See results.txt");
			}
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static Database createDatabase(final String customerFilename, final String productFilename) {
		try (Reader cr = new FileReader(customerFilename); Reader pr = new FileReader(productFilename)) {
			return new DatabaseImpl(cr, pr);
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}
}
