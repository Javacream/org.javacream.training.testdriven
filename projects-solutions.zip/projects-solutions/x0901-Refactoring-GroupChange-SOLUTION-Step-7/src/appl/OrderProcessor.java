package appl;

import domain.Customer;
import domain.Order;
import domain.Product;
import services.Database;
import services.Printer;
import util.GroupChanger;

public class OrderProcessor implements GroupChanger.Processor<Order> {

	private final Database database;
	private final Printer printer;
	private int groupSum;
	private int totalSum;

	public OrderProcessor(final Database database, final Printer printer) {
		this.database = database;
		this.printer = printer;
	}

	@Override
	public void processBegin() {
		this.totalSum = 0;
		this.printer.printBegin();
	}

	@Override
	public void processGroupBegin(final Order order) {
		this.groupSum = 0;
		final Customer customer = this.database.getCustomer(order.customerNr);
		this.printer.printGroupBegin(customer);
	}

	@Override
	public void processPosition(final Order order) {
		final Product product = this.database.getProduct(order.productNr);
		final int value = order.amount * product.price;
		this.groupSum += value;
		this.printer.printPosition(order, product, value);
	}

	@Override
	public void processGroupEnd(final Order order) {
		this.totalSum += this.groupSum;
		this.printer.printGroupEnd(this.groupSum);
	}

	@Override
	public void processEnd() {
		this.printer.printEnd(this.totalSum);
	}
}

