package util;

import java.util.Iterator;
import java.util.function.Function;

public class GroupChanger {

	public static interface Processor<T> {
		public abstract void processBegin();
		public abstract void processGroupBegin(T object);
		public abstract void processPosition(T object);
		public abstract void processGroupEnd(T object);
		public abstract void processEnd();
	}

	public static <T, K> void run(final Iterator<T> iterator, final Function<T, K> keyExtractor,
			final Processor<T> processor) {
		T current = next(iterator);
		processor.processBegin();
		while (current != null) {
			final K key = keyExtractor.apply(current);
			processor.processGroupBegin(current);
			T old = current;
			while (current != null && keyExtractor.apply(current).equals(key)) {
				processor.processPosition(current);
				old = current;
				current = next(iterator);
			}
			processor.processGroupEnd(old);
		}
		processor.processEnd();
	}

	private static <T> T next(final Iterator<T> iterator) {
		return iterator.hasNext() ? iterator.next() : null;
	}
}
