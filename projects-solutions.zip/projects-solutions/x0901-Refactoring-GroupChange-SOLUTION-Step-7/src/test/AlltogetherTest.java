package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ CSVReaderTest.class, DatabaseImplTest.class, OrdersTest.class, GroupChangerTest.class })

public class AlltogetherTest {
}
