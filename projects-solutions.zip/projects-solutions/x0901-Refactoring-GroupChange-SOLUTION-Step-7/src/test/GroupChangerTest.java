package test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import domain.Order;
import util.GroupChanger;

public class GroupChangerTest {

	private GroupChanger.Processor<Order> processor;

	@SuppressWarnings("unchecked")
	@Before
	public void before() {
		this.processor = mock(GroupChanger.Processor.class);
	}

	@Test
	public void testEmptyInput() {

		final List<Order> orders = new ArrayList<>();

		GroupChanger.run(orders.iterator(), order -> order.customerNr, this.processor);

		verify(this.processor).processBegin();
		verify(this.processor).processEnd();
	}

	@Test
	public void testOneGroup() {

		final List<Order> orders = new ArrayList<>();
		orders.add(new Order(1000, 100, 10));
		orders.add(new Order(1000, 200, 20));

		GroupChanger.run(orders.iterator(), order -> order.customerNr, this.processor);

		verify(this.processor).processBegin();
		verify(this.processor).processGroupBegin(orders.get(0));
		verify(this.processor).processPosition(orders.get(0));
		verify(this.processor).processPosition(orders.get(1));
		verify(this.processor).processGroupEnd(orders.get(1));
		verify(this.processor).processEnd();
	}


	@Test
	public void testTwoGroups() {

		final List<Order> orders = new ArrayList<>();
		orders.add(new Order(1000, 100, 10));
		orders.add(new Order(1000, 200, 20));
		orders.add(new Order(2000, 100, 100));

		GroupChanger.run(orders.iterator(), order -> order.customerNr, this.processor);

		verify(this.processor).processBegin();
		verify(this.processor).processGroupBegin(orders.get(0));
		verify(this.processor).processPosition(orders.get(0));
		verify(this.processor).processPosition(orders.get(1));
		verify(this.processor).processGroupEnd(orders.get(1));
		verify(this.processor).processGroupBegin(orders.get(2));
		verify(this.processor).processPosition(orders.get(2));
		verify(this.processor).processGroupEnd(orders.get(2));
		verify(this.processor).processEnd();
	}
}
