package circuits;

import java.util.ArrayList;
import java.util.List;

public class Output extends Port {

	final List<Input> targets = new ArrayList<>();

	public Output(final Circuit owner) {
		super(owner);
	}

	public void connectTo(final Input input) {
		input.source = this;
		this.targets.add(input);
		input.setState(this.getState());
		input.getOwner().calculate();
	}
}
