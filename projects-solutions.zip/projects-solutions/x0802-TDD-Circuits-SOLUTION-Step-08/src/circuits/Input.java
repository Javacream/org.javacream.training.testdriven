package circuits;

public class Input extends Port {

	Output source;

	public Input(final Circuit owner) {
		super (owner);
	}

	public void toggle() {
		this.setState(! this.getState());
		this.getOwner().calculate();
	}
}
