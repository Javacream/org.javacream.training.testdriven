Circuit mit Logic verbunden
Circuit nun final und instantiierbar


