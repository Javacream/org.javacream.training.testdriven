package appl;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;

import domain.Customer;
import domain.Order;
import domain.Product;
import services.Database;
import services.DatabaseImpl;
import services.Printer;
import services.PrinterImpl;
import util.CSVReader;

public class Application {

	public static void main(final String[] args) {

		final Database database = createDatabase("customers.txt", "products.txt");

		try (PrintWriter w = new PrintWriter("result.txt")) {
			try (FileReader r = new FileReader("orders.txt")) {
				final Printer printer = new PrinterImpl(w);
				final CSVReader reader = new CSVReader(r, 3, ";");
				printer.printBegin();
				Order order = readOrder(reader);
				int sum = 0;
				while (order != null) {
					final int customerNr = order.customerNr;
					final Customer customer = database.getCustomer(customerNr);
					printer.printGroupBegin(customer);
					int groupSum = 0;
					while (order != null && order.customerNr == customerNr) {
						final int productNr = order.productNr;
						final Product product = database.getProduct(productNr);
						final int positionPrice = product.price * order.amount;
						printer.printPosition(order, product, positionPrice);
						groupSum += positionPrice;
						order = readOrder(reader);
					}
					sum += groupSum;
					printer.printGroupEnd(groupSum);
				}
				printer.printEnd(sum);
				System.out.println("Done. See results.txt");
			}
		}
		catch (final IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static Order readOrder(final CSVReader reader) throws IOException {
		final String[] tokens = reader.readLine();
		if (tokens == null)
			return null;
		final int customerNr = Integer.parseInt(tokens[0]);
		final int produceNr = Integer.parseInt(tokens[1]);
		final int amount = Integer.parseInt(tokens[2]);
		return new Order(customerNr, produceNr, amount);
	}

	private static Database createDatabase(final String customerFilename, final String productFilename) {
		try (Reader cr = new FileReader(customerFilename); Reader pr = new FileReader(productFilename)) {
			return new DatabaseImpl(cr, pr);
		}
		catch(final IOException e) {
			throw new RuntimeException(e);
		}
	}
}
