package services;

import java.io.PrintWriter;

import domain.Customer;
import domain.Order;
import domain.Product;

public class PrinterImpl implements Printer {
	private final PrintWriter writer;

	public PrinterImpl(final PrintWriter writer) {
		this.writer = writer;
	}

	@Override
	public void printBegin() {
		this.writer.println("Orders");
		this.writer.println();
	}

	@Override
	public void printGroupBegin(final Customer customer) {
		this.writer.println(customer.nr + " " + customer.name);
	}

	@Override
	public void printPosition(final Order order, final Product product, final int value) {
		this.writer.println(
				"\t" + product.nr + " " + product.name + " " + order.amount + " " + product.price + " " + value);
	}

	@Override
	public void printGroupEnd(final int groupSum) {
		this.writer.println("\t---------");
		this.writer.println("\t" + groupSum);
		this.writer.println();
	}

	@Override
	public void printEnd(final int totalSum) {
		this.writer.println("Total:\t" + totalSum);
	}
}
