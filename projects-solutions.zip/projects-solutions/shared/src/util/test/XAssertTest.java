package util.test;

import java.io.IOException;

import org.junit.Test;

public class XAssertTest {

	@Test
	public void testExact() {
		XAssert.assertThrows(Exception.class, () -> {
			throw new Exception();
		});
	}

	@Test
	public void testDerived() {
		XAssert.assertThrows(Exception.class, () -> {
			throw new IOException();
		});
	}

	@Test
	public void testRuntimeException() {
		XAssert.assertThrows(Exception.class, () -> {
			throw new RuntimeException();
		});
	}

	@Test
	public void testRuntimeExceptionExact() {
		XAssert.assertThrows(RuntimeException.class, () -> {
			throw new RuntimeException();
		});
	}

	@Test(expected = AssertionError.class)
	public void testFailure() {
		XAssert.assertThrows(IOException.class, () -> {
			throw new Exception();
		});
	}
}
