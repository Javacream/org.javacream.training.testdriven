package util.test;

public class XAssert {

	public static <T> void assertThrows(final Class<?> exceptionType, final Func<T> func) {
		try {
			func.apply();
			throw new AssertionError("Expected exception (but was not thrown): " + exceptionType.getName());
		}
		catch (final AssertionError e) {
			throw e;
		}
		catch (final Exception e) {
			if (! exceptionType.isAssignableFrom(e.getClass()))
				throw new AssertionError("Expected exception: " + exceptionType.getName() + ". But was: " + e.getClass().getName());
		}
	}

	public static <T> void assertThrows(final Class<?> exceptionType, final Proc proc) {
		try {
			proc.execute();
			throw new AssertionError("Expected exception (but was not thrown): " + exceptionType.getName());
		}
		catch (final AssertionError e) {
			throw e;
		}
		catch (final Exception e) {
			if (! exceptionType.isAssignableFrom(e.getClass()))
				throw new AssertionError("Expected exception: " + exceptionType.getName() + ". But was: " + e.getClass().getName());
		}
	}
}
