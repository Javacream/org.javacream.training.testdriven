package util.test;

@FunctionalInterface
public interface Proc {
	public abstract void execute() throws Exception;
}
