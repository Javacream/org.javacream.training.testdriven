package util.test;

@FunctionalInterface
public interface Func<T> {
	public abstract T apply() throws Exception;
}
