package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class CSVReader {

	private final BufferedReader reader;
	private final int columnCount;
	private final String seperator;
	private final String[] header;

	public CSVReader(final Reader reader, final int columnCount, final String seperator, final boolean withHeader) {
		this.reader = new BufferedReader(reader);
		this.columnCount = columnCount;
		this.seperator = seperator;
		this.header = withHeader ? this.readLine() : null;
	}

	public CSVReader(final Reader reader, final int columnCount, final String seperator) {
		this(reader, columnCount, seperator, false);
	}

	public String[] getHeader() {
		if (this.header == null)
			throw new RuntimeException("illegal call of getHeader");
		return this.header.clone();
	}

	public String[] readLine() {
		while (true) {
			try {
				String line = this.reader.readLine();
				if (line == null)
					return null;
				line = line.trim();
				if (line.isEmpty())
					continue;
				final String[] tokens = line.split(this.seperator);
				for (int i = 0; i < tokens.length; i++)
					tokens[i] = tokens[i].trim();
				if (tokens.length != this.columnCount)
					throw new RuntimeException("illegal line: " + line);
				return tokens;
			}
			catch (final IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
}
