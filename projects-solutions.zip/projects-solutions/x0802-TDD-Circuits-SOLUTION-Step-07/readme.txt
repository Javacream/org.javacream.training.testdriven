bei Port owner eingef�hrt
toggle nach Input verschieben
	delegiert nach owner.calculate
