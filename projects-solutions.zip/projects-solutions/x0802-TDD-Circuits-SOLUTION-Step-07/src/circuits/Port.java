package circuits;

public class Port {
	private final Circuit owner;
	private boolean state;
	public Port(final Circuit owner) {
		this.owner = owner;
	}
	public Circuit getOwner() {
		return this.owner;
	}
	void setState(final boolean state) {
		this.state = state;
	}
	public boolean getState() {
		return this.state;
	}
}
