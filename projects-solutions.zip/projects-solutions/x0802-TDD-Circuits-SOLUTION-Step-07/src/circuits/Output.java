package circuits;

public class Output extends Port {
	public Output(final Circuit owner) {
		super (owner);
	}
}
