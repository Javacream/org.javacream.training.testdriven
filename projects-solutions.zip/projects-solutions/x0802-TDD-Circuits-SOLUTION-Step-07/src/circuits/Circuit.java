package circuits;

public abstract class Circuit {
	protected final Input[] inputs;
	protected final Output[] outputs;

	public Circuit(final int inputCount, final int outputCount) {
		this.inputs = new Input[inputCount];
		this.outputs = new Output[outputCount];
		for (int i = 0; i < inputCount; i++)
			this.inputs[i] = new Input(this);
		for (int i = 0; i < outputCount; i++)
			this.outputs[i] = new Output(this);
	}

	abstract void calculate();

	public final int getInputCount() {
		return this.inputs.length;
	}

	public final int getOutputCount() {
		return this.outputs.length;
	}

	public Input input(final int index) {
		return this.inputs[index];
	}

	public Output output(final int index) {
		return this.outputs[index];
	}
}
