package test;

import org.junit.Assert;
import org.junit.Test;

import circuits.AndCircuit;
import circuits.Circuit;
import circuits.NotCircuit;
import circuits.OrCircuit;

public class CircuitTest {
	@Test
	public void testAnd() {
		final Circuit c = new AndCircuit();
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testOr() {
		final Circuit c = new OrCircuit();
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testNot() {
		final Circuit c = new NotCircuit();
		Assert.assertEquals(1, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.output(0).getState());
	}

	@Test
	public void testToggleAnd() {
		final Circuit c = new AndCircuit();
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}
	@Test
	public void testToggleOr() {
		final Circuit c = new OrCircuit();
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}
	@Test
	public void testToggleNot() {
		final Circuit c = new NotCircuit();
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.output(0).getState());
	}
}
