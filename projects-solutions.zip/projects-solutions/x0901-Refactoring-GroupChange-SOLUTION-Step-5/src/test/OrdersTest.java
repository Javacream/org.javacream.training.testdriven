package test;

import java.io.StringReader;
import java.util.Iterator;

import org.junit.Assert;
import org.junit.Test;

import appl.Orders;
import domain.Order;
import util.CSVReader;

public class OrdersTest {

	@Test
	public void testEmptyInput() {
		final StringReader reader = new StringReader("");
		final Iterator<Order> iter = new Orders(new CSVReader(reader, 3, ";"));
		Assert.assertFalse(iter.hasNext());
	}

	@Test
	public void testTowOrders() {
		final StringReader reader = new StringReader("1000;100;10\n2000;200;20\n");
		final Iterator<Order> iter = new Orders(new CSVReader(reader, 3, ";"));
		Assert.assertTrue(iter.hasNext());
		this.assertEquals(new Order(1000, 100, 10), iter.next());
		Assert.assertTrue(iter.hasNext());
		this.assertEquals(new Order(2000, 200, 20), iter.next());
		Assert.assertFalse(iter.hasNext());

	}

	private void assertEquals(final Order o0, final Order o1) {
		Assert.assertEquals(o0.customerNr, o1.customerNr);
		Assert.assertEquals(o0.productNr, o1.productNr);
		Assert.assertEquals(o0.amount, o1.amount);
	}
}
