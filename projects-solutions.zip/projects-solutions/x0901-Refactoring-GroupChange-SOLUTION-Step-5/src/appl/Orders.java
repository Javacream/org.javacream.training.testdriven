package appl;

import java.util.Iterator;

import domain.Order;
import util.CSVReader;

public class Orders implements Iterator<Order> {

	private final CSVReader reader;
	private Order current;

	public Orders(final CSVReader reader) {
		this.reader = reader;
		this.current = this.readOrder();
	}

	@Override
	public boolean hasNext() {
		return this.current != null;
	}

	@Override
	public Order next() {
		final Order order = this.current;
		this.current = this.readOrder();
		return order;
	}

	private Order readOrder() {
		final String[] tokens = this.reader.readLine();
		if (tokens == null)
			return null;
		final int customerNr = Integer.parseInt(tokens[0]);
		final int produceNr = Integer.parseInt(tokens[1]);
		final int amount = Integer.parseInt(tokens[2]);
		return new Order(customerNr, produceNr, amount);
	}
}
