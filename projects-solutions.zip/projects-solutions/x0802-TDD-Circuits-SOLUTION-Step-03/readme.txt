Refactoring:

class Circuit:
	Instanzvariablen inputCount und outputCount entfallen
	