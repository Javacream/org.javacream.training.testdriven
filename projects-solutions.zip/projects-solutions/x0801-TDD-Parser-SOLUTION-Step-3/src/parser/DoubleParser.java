package parser;

public interface DoubleParser {
	public abstract double parse();
}
