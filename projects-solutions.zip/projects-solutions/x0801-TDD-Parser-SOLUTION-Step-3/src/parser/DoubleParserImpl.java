package parser;

import scanner.Scanner;
import scanner.Symbol;

public class DoubleParserImpl implements DoubleParser {
	private final Scanner scanner;

	public DoubleParserImpl(final Scanner scanner) {
		this.scanner = scanner;
		this.scanner.next();
	}

	@Override
	public double parse() {
		if (this.scanner.currentSymbol() != Symbol.NUMBER)
			throw new RuntimeException("Number expected");
		final double value = this.scanner.getNumber();
		this.scanner.next();
		if (this.scanner.currentSymbol() != null)
			throw new RuntimeException("EOF expected");
		return value;
	}
}
