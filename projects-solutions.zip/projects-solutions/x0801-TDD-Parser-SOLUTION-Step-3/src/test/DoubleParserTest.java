package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import parser.DoubleParser;
import parser.DoubleParserImpl;
import scanner.ScannerImpl;
import util.test.XAssert;

public class DoubleParserTest {

	@Test
	public void test() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2.71  ")));
		Assert.assertEquals(2.71, parser.parse(), 0);
	}

	@Test
	public void testEmpty() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" ")));
		XAssert.assertThrows(RuntimeException.class, () -> parser.parse());
	}

	@Test
	public void testTooManyNumbers() {
		final DoubleParser parser = new DoubleParserImpl(new ScannerImpl(new StringReader(" 2.71 3.14")));
		XAssert.assertThrows(RuntimeException.class, () -> parser.parse());
	}
}
