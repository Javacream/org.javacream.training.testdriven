package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class CSVReader {

	private final BufferedReader reader;
	private final int columnCount;
	private final String seperator;

	public CSVReader(final Reader reader, final int columnCount, final String seperator) {
		this.reader = new BufferedReader(reader);
		this.columnCount = columnCount;
		this.seperator = seperator;
	}

	public String[] readLine() {
		while (true) {
			try {
				String line = this.reader.readLine();
				if (line == null)
					return null;
				line = line.trim();
				if (line.isEmpty())
					continue;
				final String[] tokens = line.split(this.seperator);
				for (int i = 0; i < tokens.length; i++)
					tokens[i] = tokens[i].trim();
				if (tokens.length != this.columnCount)
					throw new RuntimeException("illegal line: " + line);
				return tokens;
			}
			catch (final IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
}
