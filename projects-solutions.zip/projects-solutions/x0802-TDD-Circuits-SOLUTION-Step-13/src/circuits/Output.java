package circuits;

import java.util.ArrayList;
import java.util.List;

public class Output {

	private final Circuit owner;

	private boolean state;
	final List<Input> targets = new ArrayList<>();

	public Output(final Circuit owner) {
		this.owner = owner;
	}

	public Circuit getOwner() {
		return this.owner;
	}

	void setState(final boolean state) {
		if (state != this.state) {
			this.state = state;
			this.targets.forEach(target -> target.setState(this.getState()));
		}
	}

	public boolean getState() {
		return this.state;
	}

	public void connectTo(final Input input) {
		if (input.isConnected())
			throw new RuntimeException("cannot connectTo. input is connected");
		if (input.getOwner().canReach(this.getOwner()))
			throw new RuntimeException("Circular connections not allowed");
		input.source = this;
		this.targets.add(input);
		input.setState(this.getState());
		input.getOwner().calculate();
	}

	public boolean canReach(final Circuit ciruit) {
		for (final Input input : this.targets) {
			if (input.getOwner() == ciruit || input.getOwner().canReach(ciruit))
				return true;
		}
		return false;
	}

}
