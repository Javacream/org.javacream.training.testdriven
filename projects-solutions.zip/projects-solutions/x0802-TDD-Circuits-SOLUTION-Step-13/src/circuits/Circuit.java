package circuits;

import logics.Logic;

public final class Circuit {
	private Logic logic;
	protected final Input[] inputs;
	protected final Output[] outputs;

	public Circuit(final Logic logic) {
		this.logic = logic;
		this.inputs = new Input[logic.inputCount];
		this.outputs = new Output[logic.outputCount];
		for (int i = 0; i < logic.inputCount; i++)
			this.inputs[i] = new Input(this);
		for (int i = 0; i < logic.outputCount; i++)
			this.outputs[i] = new Output(this);
		this.calculate();
	}

	void calculate() {
		final boolean[] inputStates = new boolean[this.inputs.length];
		for (int i = 0; i < this.inputs.length; i++)
			inputStates[i] = this.inputs[i].getState();
		final boolean[] outputStates = this.logic.calc(inputStates);
		for (int i = 0; i < this.outputs.length; i++)
			this.outputs[i].setState(outputStates[i]);
	}

	public void setLogic(final Logic logic) {
		this.logic = logic;
		this.calculate();
	}

	public Logic getLogic() {
		return this.logic;
	}

	public int getInputCount() {
		return this.inputs.length;
	}

	public int getOutputCount() {
		return this.outputs.length;
	}

	public Input input(final int index) {
		return this.inputs[index];
	}

	public Output output(final int index) {
		return this.outputs[index];
	}

	public boolean canReach(final Circuit other) {
		for (final Output output : this.outputs) {
			if (output.canReach(other))
				return true;
		}
		return false;
	}

}
