package test;

import org.junit.Assert;
import org.junit.Test;

import circuits.Circuit;
import logics.AndLogic;
import logics.Logic;
import logics.NotLogic;
import logics.OrLogic;
import util.test.XAssert;

public class CircuitTest {
	@Test
	public void testAnd() {
		final Circuit c = new Circuit(AndLogic.instance);
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testOr() {
		final Circuit c = new Circuit(OrLogic.instance);
		Assert.assertEquals(2, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testNot() {
		final Circuit c = new Circuit(NotLogic.instance);
		Assert.assertEquals(1, c.getInputCount());
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.output(0).getState());
	}

	@Test
	public void testToggleAnd() {
		final Circuit c = new Circuit(AndLogic.instance);
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testToggleOr() {
		final Circuit c = new Circuit(OrLogic.instance);
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.input(1).getState());
		Assert.assertTrue(c.output(0).getState());
		c.input(1).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertFalse(c.input(1).getState());
		Assert.assertFalse(c.output(0).getState());
	}

	@Test
	public void testToggleNot() {
		final Circuit c = new Circuit(NotLogic.instance);
		c.input(0).toggle();
		Assert.assertTrue(c.input(0).getState());
		Assert.assertFalse(c.output(0).getState());
		c.input(0).toggle();
		Assert.assertFalse(c.input(0).getState());
		Assert.assertTrue(c.output(0).getState());
	}

	@Test
	public void testConnectAndWithNot() {
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);

		and.output(0).connectTo(not.input(0));
		Assert.assertTrue(not.output(0).getState());
	}

	@Test
	public void testConnectNotWithNot() {
		final Circuit not0 = new Circuit(NotLogic.instance);
		final Circuit not1 = new Circuit(NotLogic.instance);

		not0.output(0).connectTo(not1.input(0));
		Assert.assertFalse(not1.output(0).getState());
	}

	@Test
	public void testConnectAndWithNotAndToggle() {
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);

		and.output(0).connectTo(not.input(0));

		and.input(0).toggle();
		Assert.assertTrue(not.output(0).getState());
		and.input(1).toggle();
		Assert.assertFalse(not.output(0).getState());
	}

	@Test
	public void testTogglePrecondition()
	{
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);
		not.input(0).toggle();
		and.output(0).connectTo(not.input(0));
		XAssert.assertThrows(RuntimeException.class, () -> not.input(0).toggle());
	}

	@Test
	public void testConnectToPrecondition()
	{
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);
		and.output(0).connectTo(not.input(0));
		XAssert.assertThrows(RuntimeException.class, () -> and.output(0).connectTo(not.input(0)));
	}

	@Test
	public void testConnected() {
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);
		Assert.assertFalse(not.input(0).isConnected());
		and.output(0).connectTo(not.input(0));
		Assert.assertTrue(not.input(0).isConnected());
	}

	@Test
	public void TestCircularConnection()
	{
		final Circuit and = new Circuit(AndLogic.instance);
		final Circuit not = new Circuit(NotLogic.instance);
		Assert.assertFalse(and.canReach(not));
		and.output(0).connectTo(not.input(0));
		Assert.assertTrue(and.canReach(not));
		XAssert.assertThrows(RuntimeException.class, () -> not.output(0).connectTo(and.input(0)));
		XAssert.assertThrows(RuntimeException.class, () -> not.output(0).connectTo(and.input(1)));
	}

	@Test
	public void TestNotLogic() {
		final Logic logic = NotLogic.instance;
		Assert.assertEquals(1, logic.inputCount);
		Assert.assertEquals(1, logic.outputCount);
		Assert.assertFalse(logic.calc(new boolean[] { true })[0]);
		Assert.assertTrue(logic.calc(new boolean[] { false })[0]);
	}

}
