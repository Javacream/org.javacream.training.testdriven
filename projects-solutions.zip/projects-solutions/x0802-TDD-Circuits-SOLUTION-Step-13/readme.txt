Erkennen und Zurueckweisen zirkulaere Connections
