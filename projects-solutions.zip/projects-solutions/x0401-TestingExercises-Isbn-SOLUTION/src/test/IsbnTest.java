package test;

import org.junit.Assert;
import org.junit.Test;

import appl.Isbn;
import util.test.XAssert;

public class IsbnTest {

	@Test
	public void TestCreationWithEmptyArguments()
	{
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn("", "", "", ' '));
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn(null, null, null, ' '));
	}

	@Test
	public void TestCreationWithNonNumericArguments()
	{
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn("aa", "222", "3333", '4'));
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn("11", "bbb", "3333", '4'));
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn("11", "222", "cccc", '4'));
		XAssert.assertThrows(IllegalArgumentException.class, () -> new Isbn("11", "222", "3333", 'd'));
	}

	@Test
	public void TestCreationWithFourArguments() {
		final Isbn isbn = new Isbn("11", "222", "3333", '4');
		Assert.assertEquals("11", isbn.country);
		Assert.assertEquals("222", isbn.publisher);
		Assert.assertEquals("3333", isbn.number);
		Assert.assertEquals('4', isbn.check);
	}

	@Test
	public void TestCreationWithOneArguments() {
		final Isbn isbn = new Isbn("11-222-3333-4");
		Assert.assertEquals("11", isbn.country);
		Assert.assertEquals("222", isbn.publisher);
		Assert.assertEquals("3333", isbn.number);
		Assert.assertEquals('4', isbn.check);
	}

	@Test
	public void TestExternalForm() {
		final Isbn isbn = new Isbn("11", "222", "3333", '4');
		Assert.assertEquals("11-222-3333-4", isbn.externalForm());
	}

	@Test
	public void TestEquals() {
		final Isbn isbn1 = new Isbn("11", "222", "3333", '4');
		final Isbn isbn2 = new Isbn("11", "222", "3333", '4');
		final Isbn isbn3 = new Isbn("77", "888", "9999", '4');
		Assert.assertTrue(isbn1.equals(isbn2));
		Assert.assertFalse(isbn1.equals(isbn3));
	}
}
