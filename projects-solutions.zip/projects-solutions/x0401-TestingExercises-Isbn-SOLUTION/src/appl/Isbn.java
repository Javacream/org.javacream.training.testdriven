package appl;

public class Isbn {

	public final String country;
	public final String publisher;
	public final String number;
	public final char check;

	public Isbn(final String country, final String publisher, final String number, final char check) {
		this.country = country;
		this.publisher = publisher;
		this.number = number;
		this.check = check;
		this.assertValid();
	}

	public Isbn(final String isbn) {
		final String[] tokens = isbn.split("-");
		if (tokens.length != 4)
			throw new IllegalArgumentException("String must contain 4 tokens");
		if (tokens[3].length() != 1)
			throw new IllegalArgumentException("check must contain exactly 1 character");
		this.country = tokens[0];
		this.publisher = tokens[1];
		this.number = tokens[2];
		this.check = tokens[3].charAt(0);
		this.assertValid();
	}

	private void assertValid() {
		assertNumeric(this.country);
		assertNumeric(this.publisher);
		assertNumeric(this.number);
		assertNumeric(String.valueOf(this.check));
		if (this.externalForm().length() != 13)
			throw new IllegalArgumentException("length must be 13");
	}

	public String externalForm() {
		return this.country + "-" + this.publisher + "-" + this.number + "-" + this.check;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.externalForm() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.check;
		result = prime * result + this.country.hashCode();
		result = prime * result + this.number.hashCode();
		result = prime * result + this.publisher.hashCode();
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null || this.getClass() != obj.getClass())
			return false;
		final Isbn other = (Isbn) obj;
		return this.country.equals(other.country)
				&& this.publisher.equals(other.publisher)
				&& this.number.equals(other.number)
				&& this.check == other.check; 
	}

	private static void assertNumeric(final String s) {
		if (s == null || s.length() == 0)
			throw new IllegalArgumentException("illegal null or empty argument");
		for (int i = 0; i < s.length(); i++) {
			final char c = s.charAt(i);
			if (!Character.isDigit(c))
				throw new IllegalArgumentException(s + " must be numeric");
		}
	}
}
