package util;

import java.io.Reader;

public class CSVMapper<T> {
	private final CSVReader csvReader;
	private final Mapper<T> mapper;

	public CSVMapper(final Class<T> cls, final Reader reader, final int columnCount, final String seperator, final String[] header) {
		this.csvReader = new CSVReader(reader, columnCount, seperator, header == null);
		this.mapper = new Mapper<T>(cls, header == null ? this.csvReader.getHeader() : header);
	}

	public CSVMapper(final Class<T> cls, final Reader reader, final int columnCount, final String seperator) {
		this(cls, reader, columnCount, seperator, null);
	}

	public T read() {
		final String[] line = this.csvReader.readLine();
		if (line == null)
			return null;
		return this.mapper.map(line);
	}
}
