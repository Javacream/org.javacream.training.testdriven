package circuits;

public abstract class Circuit {
	private final int inputCount;
	private final int outputCount;
	protected final boolean[] inputStates;
	protected final boolean[] outputStates;

	public Circuit(final int inputCount, final int outputCount) {
		this.inputCount = inputCount;
		this.outputCount = outputCount;
		this.inputStates = new boolean[inputCount];
		this.outputStates = new boolean[outputCount];
	}

	public final int getInputCount() {
		return this.inputCount;
	}

	public final int getOutputCount() {
		return this.outputCount;
	}

	public boolean inputState(final int index) {
		return this.inputStates[index];
	}

	public boolean outputState(final int index) {
		return this.outputStates[index];
	}
}
