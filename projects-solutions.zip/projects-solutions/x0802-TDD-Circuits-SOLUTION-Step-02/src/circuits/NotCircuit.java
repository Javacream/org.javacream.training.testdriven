package circuits;

public class NotCircuit extends Circuit {

	public NotCircuit() {
		super(1, 1);
		this.outputStates[0] = true;
	}
}
