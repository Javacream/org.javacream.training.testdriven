class Circuit:
	boolsche state-Arrays

siehe insb. NotCircuit!
	