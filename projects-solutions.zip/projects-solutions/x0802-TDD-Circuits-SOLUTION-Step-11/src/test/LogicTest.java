package test;

import org.junit.Assert;
import org.junit.Test;

import logics.AndLogic;
import logics.Logic;
import logics.NotLogic;
import logics.OrLogic;

public class LogicTest {
	@Test
	public void TestAndLogic() {
		final Logic logic = AndLogic.instance;
		Assert.assertEquals(2, logic.inputCount);
		Assert.assertEquals(1, logic.outputCount);
		Assert.assertTrue(logic.calc(new boolean[] { true, true })[0]);
		Assert.assertFalse(logic.calc(new boolean[] { true, false })[0]);
		Assert.assertFalse(logic.calc(new boolean[] { false, true })[0]);
		Assert.assertFalse(logic.calc(new boolean[] { false, false})[0]);
	}
	@Test
	public void TestOrLogic()
	{
		final Logic logic = OrLogic.instance;
		Assert.assertEquals(2, logic.inputCount);
		Assert.assertEquals(1, logic.outputCount);
		Assert.assertTrue(logic.calc(new boolean[] { true, true })[0]);
		Assert.assertTrue(logic.calc(new boolean[] { true, false })[0]);
		Assert.assertTrue(logic.calc(new boolean[] { false, true })[0]);
		Assert.assertFalse(logic.calc(new boolean[] { false, false })[0]);
	}
	@Test
	public void TestNotLogic()
	{
		final Logic logic = NotLogic.instance;
		Assert.assertEquals(1, logic.inputCount);
		Assert.assertEquals(1, logic.outputCount);
		Assert.assertFalse(logic.calc(new boolean[] { true })[0]);
		Assert.assertTrue(logic.calc(new boolean[] { false })[0]);
	}

}
