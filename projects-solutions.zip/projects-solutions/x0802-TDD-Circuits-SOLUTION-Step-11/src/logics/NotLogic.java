package logics;

public class NotLogic extends Logic {

	public static final NotLogic instance = new NotLogic();

	private NotLogic() {
		super(1, 1);
	}

	@Override
	public boolean[] calc(final boolean[] inputStates) {
		return new boolean[] { ! inputStates[0] };
	}

}
