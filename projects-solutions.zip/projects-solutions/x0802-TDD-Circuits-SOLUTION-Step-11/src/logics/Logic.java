package logics;

public abstract class Logic {

	public final int inputCount;
	public final int outputCount;

	public Logic(final int inputCount, final int outputCount) {
		this.inputCount = inputCount;
		this.outputCount = outputCount;
	}

	public abstract boolean[] calc(boolean[] inputStates);

}
