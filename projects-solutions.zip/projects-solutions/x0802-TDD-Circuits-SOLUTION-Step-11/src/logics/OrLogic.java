package logics;

public class OrLogic extends Logic {

	public static final OrLogic instance = new OrLogic();

	private OrLogic() {
		super(2, 1);
	}

	@Override
	public boolean[] calc(final boolean[] inputStates) {
		return new boolean[] { inputStates[0] || inputStates[1] };
	}

}
