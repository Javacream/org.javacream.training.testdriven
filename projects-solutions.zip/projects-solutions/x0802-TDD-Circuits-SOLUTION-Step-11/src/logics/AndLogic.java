package logics;

public class AndLogic extends Logic {

	public static final AndLogic instance = new AndLogic();

	private AndLogic() {
		super(2, 1);
	}

	@Override
	public boolean[] calc(final boolean[] inputStates) {
		return new boolean[] { inputStates[0] && inputStates[1] };
	}

}
