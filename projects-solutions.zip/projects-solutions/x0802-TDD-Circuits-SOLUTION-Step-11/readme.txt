Logic eingef�hrt

