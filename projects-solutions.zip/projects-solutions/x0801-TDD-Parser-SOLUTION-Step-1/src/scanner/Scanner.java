package scanner;

public interface Scanner {
	public abstract void next();
	public abstract Symbol currentSymbol();
	public abstract double getNumber();
}
