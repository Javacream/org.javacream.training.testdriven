package scanner;

public enum Symbol {
	PLUS, MINUS, TIMES, DIV, OPEN, CLOSE, NUMBER
}
