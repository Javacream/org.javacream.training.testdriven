package scanner;

import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

public class ScannerImpl implements Scanner {

	private static Map<Character, Symbol> operators = new HashMap<Character, Symbol>();

	static {
		operators.put('+', Symbol.PLUS);
		operators.put('-', Symbol.MINUS);
		operators.put('*', Symbol.TIMES);
		operators.put('/', Symbol.DIV);
		operators.put('(', Symbol.OPEN);
		operators.put(')', Symbol.CLOSE);
	}

	private final Reader reader;
	private int currentChar;
	private Symbol currentSymbol;

	public ScannerImpl(final Reader reader) {
		this.reader = reader;
		this.nextChar();
	}

	@Override
	public void next() {
		while(Character.isWhitespace(this.currentChar))
			this.nextChar();
		if (this.currentChar == -1) {
			this.currentSymbol = null;
			return;
		}
		this.currentSymbol = operators.get((char)this.currentChar);
		if (this.currentSymbol == null)
			throw new RuntimeException("unexpected char: " + (char)this.currentChar + " code = " + this.currentChar);
		this.nextChar();
	}

	@Override
	public Symbol currentSymbol() {
		return this.currentSymbol;
	}

	@Override
	public double getNumber() {
		return 0;
	}

	private void nextChar() {
		try {
			this.currentChar = this.reader.read();
		}
		catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}
}
