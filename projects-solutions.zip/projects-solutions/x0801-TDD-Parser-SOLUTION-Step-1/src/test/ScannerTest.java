package test;

import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import scanner.Scanner;
import scanner.ScannerImpl;
import scanner.Symbol;
import util.test.XAssert;

public class ScannerTest {
	@Test
	public void testEOF() {
		final Scanner scanner = new ScannerImpl(new StringReader(""));
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}

	@Test
	public void testOperators() {
		final Scanner scanner = new ScannerImpl(new StringReader("+-*/"));
		scanner.next();
		Assert.assertSame(Symbol.PLUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.MINUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.TIMES, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.DIV, scanner.currentSymbol());
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}

	@Test
	public void testIllegalChar() {
		final Scanner scanner = new ScannerImpl(new StringReader("?"));
		XAssert.assertThrows(RuntimeException.class, () -> scanner.next());
	}

	@Test
	public void testWhitespace() {
		final Scanner scanner = new ScannerImpl(new StringReader(" + -  */  "));
		scanner.next();
		Assert.assertSame(Symbol.PLUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.MINUS, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.TIMES, scanner.currentSymbol());
		scanner.next();
		Assert.assertSame(Symbol.DIV, scanner.currentSymbol());
		scanner.next();
		Assert.assertNull(scanner.currentSymbol());
	}
}
