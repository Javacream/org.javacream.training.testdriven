package test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import appl.OrderGroupChanger;
import domain.Customer;
import domain.Order;
import domain.Product;
import services.Database;
import services.Printer;

public class OrderGroupChangerTest {

	private Printer printer;
	private Database database;

	@Before
	public void before() {
		this.printer = mock(Printer.class);
		this.database = mock(Database.class);
	}

	@Test
	public void testEmptyInput() {

		final List<Order> orders = new ArrayList<>();

		OrderGroupChanger.run(orders.iterator(), this.database, this.printer);

		verify(this.printer).printBegin();
		verify(this.printer).printEnd(0);
	}

	@Test
	public void testOneGroup() {

		final List<Order> orders = new ArrayList<>();
		orders.add(new Order(1000, 100, 10));
		orders.add(new Order(1000, 200, 20));

		final Customer c = new Customer(1000, "Nowak");
		final Product p1 = new Product(100, "Jever", 3);
		final Product p2 = new Product(200, "Bitburger", 2);

		when(this.database.getCustomer(1000)).thenReturn(c);
		when(this.database.getProduct(100)).thenReturn(p1);
		when(this.database.getProduct(200)).thenReturn(p2);

		OrderGroupChanger.run(orders.iterator(), this.database, this.printer);

		verify(this.printer).printBegin();
		verify(this.printer).printGroupBegin(c);
		verify(this.printer).printPosition(orders.get(0), p1, 30);
		verify(this.printer).printPosition(orders.get(1), p2, 40);
		verify(this.printer).printGroupEnd(70);
		verify(this.printer).printEnd(70);
	}

	@Test
	public void testTwoGroups() {

		final List<Order> orders = new ArrayList<>();
		orders.add(new Order(1000, 100, 10));
		orders.add(new Order(1000, 200, 20));
		orders.add(new Order(2000, 100, 100));

		final Customer c1 = new Customer(1000, "Nowak");
		final Customer c2 = new Customer(2000, "Ruepoe");
		final Product p1 = new Product(100, "Jever", 3);
		final Product p2 = new Product(200, "Bitburger", 2);

		when(this.database.getCustomer(1000)).thenReturn(c1);
		when(this.database.getCustomer(2000)).thenReturn(c2);
		when(this.database.getProduct(100)).thenReturn(p1);
		when(this.database.getProduct(200)).thenReturn(p2);

		OrderGroupChanger.run(orders.iterator(), this.database, this.printer);

		verify(this.printer).printBegin();
		verify(this.printer).printGroupBegin(c1);
		verify(this.printer).printPosition(orders.get(0), p1, 30);
		verify(this.printer).printPosition(orders.get(1), p2, 40);
		verify(this.printer).printGroupEnd(70);
		verify(this.printer).printGroupBegin(c2);
		verify(this.printer).printPosition(orders.get(2), p1, 300);
		verify(this.printer).printGroupEnd(300);
		verify(this.printer).printEnd(370);
	}
}
