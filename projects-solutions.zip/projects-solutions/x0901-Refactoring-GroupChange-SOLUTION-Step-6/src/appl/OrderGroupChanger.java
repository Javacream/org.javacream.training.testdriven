package appl;

import java.util.Iterator;

import domain.Customer;
import domain.Order;
import domain.Product;
import services.Database;
import services.Printer;

public class OrderGroupChanger {
	public static void run(final Iterator<Order> orders, final Database database, final Printer printer) {
		printer.printBegin();
		Order order = readOrder(orders);
		int sum = 0;
		while (order != null) {
			final int customerNr = order.customerNr;
			final Customer customer = database.getCustomer(customerNr);
			printer.printGroupBegin(customer);
			int groupSum = 0;
			while (order != null && order.customerNr == customerNr) {
				final int productNr = order.productNr;
				final Product product = database.getProduct(productNr);
				final int positionPrice = product.price * order.amount;
				printer.printPosition(order, product, positionPrice);
				groupSum += positionPrice;
				order = readOrder(orders);
			}
			sum += groupSum;
			printer.printGroupEnd(groupSum);
		}
		printer.printEnd(sum);

	}
	private static Order readOrder(final Iterator<Order> orders) {
		return orders.hasNext() ? orders.next() : null;
	}
}
