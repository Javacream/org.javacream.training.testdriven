package parser;

import java.util.function.DoubleBinaryOperator;

import scanner.Scanner;

public class DoubleParserImpl extends AbstractParser<Double> {

	public DoubleParserImpl(final Scanner scanner) {
		super(scanner);
	}

	@Override
	protected Double create(final Double left, final DoubleBinaryOperator op, final Double right) {
		return op.applyAsDouble(left, right);
	}

	@Override
	protected Double create(final double value) {
		return value;
	}

}
