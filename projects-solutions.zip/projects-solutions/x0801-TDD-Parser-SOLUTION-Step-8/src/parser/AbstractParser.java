package parser;

import java.util.function.DoubleBinaryOperator;

import scanner.Scanner;
import scanner.Symbol;

public abstract class AbstractParser<T> implements Parser<T> {
	private final Scanner scanner;

	public AbstractParser(final Scanner scanner) {
		this.scanner = scanner;
		this.scanner.next();
	}

	@Override
	public T parse() {
		final T value = this.parseAdditive();
		if (this.scanner.currentSymbol() != null)
			throw new RuntimeException("EOF expected");
		return value;
	}

	public T parseAdditive() {
		T value = this.parseMultiplicative();
		while (this.scanner.currentSymbol() == Symbol.PLUS || this.scanner.currentSymbol() == Symbol.MINUS) {
			final boolean plus = this.scanner.currentSymbol() == Symbol.PLUS;
			this.scanner.next();
			final T v = this.parseMultiplicative();
			if (plus)
				value = this.create(value, (x, y) -> x + y, v);
			else
				value = this.create(value, (x, y) -> x - y, v);
		}
		return value;
	}

	public T parseMultiplicative() {
		T value = this.parseSimple();
		while (this.scanner.currentSymbol() == Symbol.TIMES || this.scanner.currentSymbol() == Symbol.DIV) {
			final boolean times = this.scanner.currentSymbol() == Symbol.TIMES;
			this.scanner.next();
			final T v = this.parseSimple();
			if (times)
				value = this.create(value, (x, y) -> x * y, v);
			else
				value = this.create(value, (x, y) -> x / y, v);
		}
		return value;
	}

	public T parseSimple() {
		if(this.scanner.currentSymbol() == Symbol.NUMBER) {
			return this.parseNumber();
		}
		if (this.scanner.currentSymbol() == Symbol.OPEN) {
			this.scanner.next();
			final T value = this.parseAdditive();
			if (this.scanner.currentSymbol() != Symbol.CLOSE) 
				throw new RuntimeException(") expected");
			this.scanner.next();
			return value;
		}
		throw new RuntimeException("Number or ( expected");
	}

	public T parseNumber() {
		if (this.scanner.currentSymbol() != Symbol.NUMBER)
			throw new RuntimeException("Number expected");
		final double value = this.scanner.getNumber();
		this.scanner.next();
		return this.create(value);
	}

	protected abstract T create(final T left, final DoubleBinaryOperator op, final T right);
	protected abstract T create(final double value);

}
