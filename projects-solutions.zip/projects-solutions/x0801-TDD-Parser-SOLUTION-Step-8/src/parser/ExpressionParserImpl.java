package parser;

import java.util.function.DoubleBinaryOperator;

import expressions.BinaryExpression;
import expressions.Expression;
import expressions.NumberExpression;
import scanner.Scanner;

public class ExpressionParserImpl extends AbstractParser<Expression> {

	public ExpressionParserImpl(final Scanner scanner) {
		super(scanner);
	}

	@Override
	protected Expression create(final Expression left, final DoubleBinaryOperator op, final Expression right) {
		return new BinaryExpression(left, op, right);
	}

	@Override
	protected Expression create(final double value) {
		return new NumberExpression(value);
	}

}
