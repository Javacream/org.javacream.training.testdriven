package parser;

public interface Parser<T> {
	public abstract T parse();
}
