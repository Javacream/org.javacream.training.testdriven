package expressions;

public abstract class Expression {
	public abstract double evaluate();
}
