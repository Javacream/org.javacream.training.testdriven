package expressions;

import java.util.function.DoubleBinaryOperator;

public class BinaryExpression extends Expression {
	private final Expression left;
	private final DoubleBinaryOperator op;
	private final Expression right;

	public BinaryExpression(final Expression left, final DoubleBinaryOperator op, final Expression right) {
		this.left = left;
		this.op = op;
		this.right = right;
	}

	@Override
	public double evaluate() {
		return this.op.applyAsDouble(this.left.evaluate(), this.right.evaluate());
	}
}
