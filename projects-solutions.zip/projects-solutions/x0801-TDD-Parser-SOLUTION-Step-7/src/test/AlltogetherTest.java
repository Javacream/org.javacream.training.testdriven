package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ ScannerTest.class, DoubleParserTest.class, ExpressionParserTest.class })

public class AlltogetherTest {
}
