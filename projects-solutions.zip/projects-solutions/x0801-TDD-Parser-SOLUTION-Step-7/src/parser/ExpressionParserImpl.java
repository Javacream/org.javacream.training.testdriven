package parser;

import expressions.BinaryExpression;
import expressions.Expression;
import expressions.NumberExpression;
import scanner.Scanner;
import scanner.Symbol;

public class ExpressionParserImpl implements ExpressionParser {
	private final Scanner scanner;

	public ExpressionParserImpl(final Scanner scanner) {
		this.scanner = scanner;
		this.scanner.next();
	}

	@Override
	public Expression parse() {
		final Expression value = this.parseAdditive();
		if (this.scanner.currentSymbol() != null)
			throw new RuntimeException("EOF expected");
		return value;
	}

	public Expression parseAdditive() {
		Expression value = this.parseMultiplicative();
		while (this.scanner.currentSymbol() == Symbol.PLUS || this.scanner.currentSymbol() == Symbol.MINUS) {
			final boolean plus = this.scanner.currentSymbol() == Symbol.PLUS;
			this.scanner.next();
			final Expression v = this.parseMultiplicative();
			if (plus)
				value = new BinaryExpression(value, (x, y) -> x + y, v);
			else
				value = new BinaryExpression(value, (x, y) -> x - y, v);
		}
		return value;
	}

	public Expression parseMultiplicative() {
		Expression value = this.parseSimple();
		while (this.scanner.currentSymbol() == Symbol.TIMES || this.scanner.currentSymbol() == Symbol.DIV) {
			final boolean times = this.scanner.currentSymbol() == Symbol.TIMES;
			this.scanner.next();
			final Expression v = this.parseSimple();
			if (times)
				value = new BinaryExpression(value, (x, y) -> x * y, v);
			else
				value = new BinaryExpression(value, (x, y) -> x / y, v);
		}
		return value;
	}

	public Expression parseSimple() {
		if(this.scanner.currentSymbol() == Symbol.NUMBER) {
			return this.parseNumber();
		}
		if (this.scanner.currentSymbol() == Symbol.OPEN) {
			this.scanner.next();
			final Expression value = this.parseAdditive();
			if (this.scanner.currentSymbol() != Symbol.CLOSE) 
				throw new RuntimeException(") expected");
			this.scanner.next();
			return value;
		}
		throw new RuntimeException("Number or ( expected");
	}

	public Expression parseNumber() {
		if (this.scanner.currentSymbol() != Symbol.NUMBER)
			throw new RuntimeException("Number expected");
		final double value = this.scanner.getNumber();
		this.scanner.next();
		return new NumberExpression(value);
	}
}
