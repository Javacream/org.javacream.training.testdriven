package parser;

import expressions.Expression;

public interface ExpressionParser {
	public abstract Expression parse();
}
